package com.techindiana.oakstudiotv.utils;

public class AppConstant {
   public static final String YES_ACTION = "YES_ACTION";
}