package com.techindiana.oakstudiotv.activity;

import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.dao.RetroClient;
import com.techindiana.oakstudiotv.fragment.FragmentHelpandInfo;
import com.techindiana.oakstudiotv.model.CompanyProfileResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ContactActivity extends AppCompatActivity implements View.OnClickListener{
    private static final String TAG_FRAGMENT = "fragment";
    TextView tvaddress,tvemail,tvphone;
EditText edFirstname,edLastname,edAddress,edEmail,edPhone,edCompany,edMessage;
private static final String phone_no_pattern = "[789][0-9]{9}";
private static final String email_pattern = "^[a-zA-Z0-9#_~!$&'()*+,;=:.\"(),:;<>@\\[\\]\\\\]+@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*$";
String firstName,lastName,email,message,phone;
Button btnsend;
ImageView iv_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        edFirstname=findViewById(R.id.ed_firstname);
        edLastname=findViewById(R.id.ed_lastname);
        edAddress=findViewById(R.id.ed_address);
        edEmail=findViewById(R.id.ed_email);
        edPhone=findViewById(R.id.ed_phone);
        edCompany=findViewById(R.id.ed_company);
        edMessage=findViewById(R.id.ed_message);
        tvaddress=findViewById(R.id.tv_address);
        tvemail=findViewById(R.id.tv_email);
        tvphone=findViewById(R.id.tv_phone);

        initialize();
        getContactDetail();

        btnsend=findViewById(R.id.btn_send);
        btnsend.setOnClickListener(this);


    }

    private void initialize(){
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);
        iv_back=(ImageView) findViewById(R.id.iv_tabback);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                getSupportFragmentManager().beginTransaction()
//                        .add(android.R.id.content, new FragmentHelpandInfo()).commit();
//                finish();
                onBackPressed();
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btn_send:
                if (validation()){

                        final Intent emailIntent = new Intent(Intent.ACTION_SEND);
                        emailIntent.setType("plain/text");
                        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{"daminijadhav1213@gmail.com"});
//                        String message = edMessage.getText().toString();
                        String text = "Contact Detail " ;
                        String contactDetail="First Name      :" +firstName+  "\nPhone No.  :" +phone+ "\nMessage   :" +message;
                        emailIntent.putExtra(Intent.EXTRA_SUBJECT, text);
                        emailIntent.putExtra(Intent.EXTRA_TEXT, contactDetail);
//                        emailIntent.putExtra(Intent.EXTRA_STREAM, email);
//                        emailIntent.putExtra(Intent.EXTRA_TITLE,message);
                        startActivity(Intent.createChooser(emailIntent, "Sending Email......"));

                }
        }

    }


    public void getContactDetail(){
        Call<List<CompanyProfileResponse>> call= RetroClient.sdaemonApi().getContactUs();
        call.enqueue(new Callback<List<CompanyProfileResponse>>() {
            @Override
            public void onResponse(Call<List<CompanyProfileResponse>> call, Response<List<CompanyProfileResponse>> response) {
                if (response.isSuccessful()){
//                    Toast.makeText(ContactActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    List<CompanyProfileResponse> companyProfileResponse=response.body();
                    if (companyProfileResponse!=null){
                        tvaddress.setVisibility(View.VISIBLE);
                        tvemail.setVisibility(View.VISIBLE);
                        tvaddress.setText("Address   : " +companyProfileResponse.get(0).getAddress());
                        tvemail.setText("Email-Id   : " +companyProfileResponse.get(0).getEmail());
//                    tvphone.setText("" +companyProfileResponse.get(0).getPhone);

                    }

                }
            }

            @Override
            public void onFailure(Call<List<CompanyProfileResponse>> call, Throwable t) {
                Toast.makeText(ContactActivity.this, "Error", Toast.LENGTH_SHORT).show();
            }
        });
    }



    public boolean validation(){
        firstName=edFirstname.getText().toString();
        lastName=edLastname.getText().toString();
        email=edEmail.getText().toString();
        message=edMessage.getText().toString();
        phone=edPhone.getText().toString();

        if (TextUtils.isEmpty(firstName)){
            edFirstname.setError("Field Cannot Be Empty");
            return false;
        }

        if (TextUtils.isEmpty(lastName)){
            edLastname.setError("Field Cannot Be Empty");
            return false;
        }


        if (TextUtils.isEmpty(email)){
            edEmail.setError("Field Cannot Be Empty");
            return false;
        }
         if (!email.matches(email_pattern)){
            edEmail.setError("Enter Valid Email-Id");
             return false;

        }

        if (TextUtils.isEmpty(phone)){
            edPhone.setError("Field Cannot Be Empty");
            return false;
        }
        if (!phone.matches(phone_no_pattern)){
            edPhone.setError("Enter Valid Phone Number");
            return false;

        }


        if (TextUtils.isEmpty(message)){
            edMessage.setError("Field Cannot Be Empty");
            return false;
        }

        return true;
    }

    @Override
    public void onBackPressed() {
        final FragmentHelpandInfo fragment = (FragmentHelpandInfo) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT);


//        FragmentManager fm=getSupportFragmentManager();
//        fm.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
//            @Override
//            public void onBackStackChanged() {
//                if(getSupportFragmentManager().getBackStackEntryCount() == 0) finish();
//            }
//        });
        super.onBackPressed();
        fragment.onBackPressed();
    }
}
