package com.techindiana.oakstudiotv.retrofit_utils.restUtils;

/**
 * Created by Rahul Patil on 14-02-2018.
 */

public class RestKeys {
    public static final String SUCCESS = "success";
    public static final String SUCCESS_VALUE = "1";
    public static final String MESSAGE = "message";
}
