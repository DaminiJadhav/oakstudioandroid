package com.techindiana.oakstudiotv.activity.brainTreePayment;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.activity.MainActivity;
import com.techindiana.oakstudiotv.model.BrainTreePostResponse;

public class BrainTreeTransactionSuccess extends AppCompatActivity {
    TextView tvtransaction, tvtransaction1, tvtransactionId;
    ImageView ivtransaction;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_brain_tree_transaction_success);
        tvtransaction = findViewById(R.id.tv_transaction);
        tvtransaction1 = findViewById(R.id.tv_transactionsuccess);
        tvtransactionId = findViewById(R.id.tv_transactionId);
        ivtransaction = findViewById(R.id.iv_transaction);
        button = findViewById(R.id.finish);


        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            String data = bundle.getString("KEY_TRANSCATION");
            if (data != null) {
                ivtransaction.setImageDrawable(getResources().getDrawable(R.drawable.checkmark));
                tvtransactionId.setText("Transaction ID  " + data);
                tvtransaction1.setText("Transaction Successful");
            } else {
//                tvtransaction.setVisibility(View.GONE);
                ivtransaction.setImageDrawable(getResources().getDrawable(R.drawable.failed));
                tvtransaction.setText(data);
            }
            //   Toast.makeText(BrainTreeTransactionSuccess.this, "success" +data , Toast.LENGTH_SHORT).show();
        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BrainTreeTransactionSuccess.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });


    }
}
