package com.techindiana.oakstudiotv.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.adapter.Plan_test_adapter;
import com.techindiana.oakstudiotv.dao.RetroClient;
import com.techindiana.oakstudiotv.dto.PlantestDTO;
import com.techindiana.oakstudiotv.model.Datum;
import com.techindiana.oakstudiotv.model.Periodlist;
import com.techindiana.oakstudiotv.model.plan_test_DTO;
import com.techindiana.oakstudiotv.utils.OnItemClickListner;

import org.json.JSONObject;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class YourPlantestsActivity extends AppCompatActivity {
    private LinearLayout ll_yourPlan, ll_monthlyPrice;
    RecyclerView rvList;
    private LinearLayoutManager mLinearLayoutManager;
    private Plan_test_adapter adapter;
    ArrayList<PlantestDTO> list1;
    ArrayList<Datum> list2;
    ArrayList<Periodlist>list3;

    ArrayList<plan_test_DTO> list;
    private Context context;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_plantests);
        initialize();
        getPlantestData();
    }

    private void initialize() {
//        list = new ArrayList<>();
//        list.add(new plan_test_DTO("Basic", "Basic, $8.99 per month (up from $7.99 in 2018). Netflix's basic plan doesn't provide high definition viewing and its programs can only be watched on one screen at a time.", 0));
//        list.add(new plan_test_DTO("Standard", "Standard, $12.99 per month (up from $10.99 in 2018). The Netflix standard offers HD videos and allows for two simultaneous viewings..", 1));
//        list.add(new plan_test_DTO("Premiun", "Premium, $15.99 per month (up from $13.99 in 2018). The top tier offering includes the ability to watch four screens at the same time. It's also the only item on the Netflix that offers a 4K viewing option..", 0));
//        list.add(new plan_test_DTO("Basic", "Basic, $15.99 per month (up from $13.99 in 2018). The top tier offering includes the ability to watch four screens at the same time. It's also the only item on the Netflix that offers a 4K viewing option..", 0));
//        list.add(new plan_test_DTO("Premiun", "Premium, $15.99 per month (up from $13.99 in 2018). The top tier offering includes the ability to watch four screens at the same time. It's also the only item on the Netflix that offers a 4K viewing option..", 0));
//        list.add(new plan_test_DTO("Premiun", "Premium, $15.99 per month (up from $13.99 in 2018). The top tier offering includes the ability to watch four screens at the same time. It's also the only item on the Netflix that offers a 4K viewing option..", 0));
        rvList = (RecyclerView) findViewById(R.id.rv_list1);
        mLinearLayoutManager = new LinearLayoutManager(context);
//        rvList.setLayoutManager(mLinearLayoutManager);
//        ((SimpleItemAnimator) rvList.getItemAnimator()).setSupportsChangeAnimations(false);
//
//        adapter = new Plan_test_adapter(YourPlantestsActivity.this, list, onClickCallback);
//        rvList.setAdapter(adapter);
//        rvList.setHasFixedSize(true);
    }

    final OnItemClickListner.OnClickCallback onClickCallback = new OnItemClickListner.OnClickCallback() {
        @Override
        public void onClicked(View view, int position, String type) {
            if (list1 != null && list1.size() > position) {
                if (type.equalsIgnoreCase("test")) {
                    try{
                        Log.e("list", "===" + "");
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    Intent intent=new Intent(YourPlantestsActivity.this,PlanSelectionActivity.class);
                    Bundle bundle=new Bundle();
                    list3 = new ArrayList<>();
                    list3.addAll(list2.get(position).getPeriodlists());

                    list1.get(0).getData().get(position).getCorePlanName();
                    bundle.putParcelableArrayList("arraylist",list3);
                    bundle.putString("TYPE", list1.get(0).getData().get(position).getCorePlanid());
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
//            getPlantestDate();
//                    Intent intent = new Intent(YourPlantestActivity.this, PlanSelectionActivity.class);
//                    startActivity(intent);
        }
    };


    private void getPlantestData(){
        Call<PlantestDTO> call= RetroClient.sdaemonApi().getPlanDetail();
        Log.e(getClass().getName(), "===" + call.request().url());
        call.enqueue(new Callback<PlantestDTO>() {
            @Override
            public void onResponse(Call<PlantestDTO> call, Response<PlantestDTO> response) {
                if (response.isSuccessful()){
//                    Toast.makeText(YourPlantestsActivity.this, "Plan success", Toast.LENGTH_SHORT).show();
                    list1=new ArrayList<>();
                    list1.add(response.body());
                    list2=new ArrayList<>();
                    int si=list1.get(0).getData().size();
                    for (int i = 0; i <si ; i++) {
                        list2.add(list1.get(0).getData().get(i));
                    }
                    rvList.setLayoutManager(mLinearLayoutManager);
                    adapter = new Plan_test_adapter(context, list2, onClickCallback);
                    rvList.setAdapter(adapter);


//                        Toast.makeText(YourPlantestsActivity.this, "Success", Toast.LENGTH_SHORT).show();
                }
                else if (response.code() == 409) {
                    try {
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        Log.i(getClass().getName(), "=========RESPONSE: 409 ");
                        String msg = jObjError.getString("message");
                        showDialoge(context, "", msg);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }else {
                    try {
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        Log.i(getClass().getName(), "=========RESPONSE: else ");
                        String msg = jObjError.getString("message");
                        showDialoge(context, "", msg);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }


            }

            @Override
            public void onFailure(Call<PlantestDTO> call, Throwable t) {
                Log.i(getClass().getName(), "--------------- onFailure " + t.getMessage());
                showDialoge(context, "", "" + t.getMessage());
            }
        });

        }

    public void showDialoge(Context context, String title, String msg) {
        try {
            AlertDialog.Builder builder;
            builder = new AlertDialog.Builder(context, R.style.dialoge);
            builder.setTitle(title)
                    .setMessage(msg)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
