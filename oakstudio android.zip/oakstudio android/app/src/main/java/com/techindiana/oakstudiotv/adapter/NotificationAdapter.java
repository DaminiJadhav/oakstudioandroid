package com.techindiana.oakstudiotv.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.TextView;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.model.Notification_details;

import java.util.ArrayList;

/**
 * Created by Rahul Patil on 23-Apr-18.
 */

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ItemRowHolder>  {

    private static LayoutInflater inflater = null;
    Context mContext;
    Animation animation;
    public static  String itemTypeId="";
    private ArrayList<Notification_details> notification_detailsArrayList;

    public NotificationAdapter(Context mContext, ArrayList<Notification_details> notification_detailsArrayList) {
        this.mContext = mContext;
        this.notification_detailsArrayList = notification_detailsArrayList;

    }
    @Override
    public ItemRowHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        viewHolder = getViewHolder(viewGroup, inflater);
        return (ItemRowHolder) viewHolder;
    }

    @NonNull
    private RecyclerView.ViewHolder getViewHolder(ViewGroup parent, LayoutInflater inflater) {
        RecyclerView.ViewHolder viewHolder;
        View v1 = inflater.inflate(R.layout.item_list_profile, parent, false);
        viewHolder = new ItemRowHolder(v1);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ItemRowHolder viewHolder, int position) {

        viewHolder.tv_head.setText(String.valueOf("\u2022 "+notification_detailsArrayList.get(position).getHeading()));
        viewHolder.tv_desc.setText(String.valueOf(notification_detailsArrayList.get(position).getDesc()));

       /* Glide.with(mContext)
                .load( notification_detailsArrayList.get(position).getImage())
                .placeholder(R.mipmap.ic_launcher)
                .centerCrop()
                .error(R.mipmap.ic_launcher)
                .into(viewHolder.movieImage);*/
       // viewHolder.movieImage.setImageResource(notification_detailsArrayList.get(position).getImage());
        //itemTypeId=notification_detailsArrayList.get(position).getId();

       // Toast.makeText(mContext, ""+itemTypeId, Toast.LENGTH_SHORT).show();

    }

    @Override
    public int getItemCount() {
        return (null != notification_detailsArrayList ? notification_detailsArrayList.size() : 0);
    }

    class ItemRowHolder extends RecyclerView.ViewHolder {
        TextView tv_head,tv_desc;

        ItemRowHolder(View view) {
            super(view);

            this.tv_head = (TextView) view.findViewById(R.id.tv_head);
            this.tv_desc = (TextView) view.findViewById(R.id.tv_desc);

        }
    }
}
