package com.techindiana.oakstudiotv.fragment;


import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.adapter.NotificationAdapter;
import com.techindiana.oakstudiotv.model.Notification_details;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentNotification extends Fragment {
    private static final int PAGE_START = 0;
    StaggeredGridLayoutManager mLayoutManager;
    private String categoryID;
    private View rootView;
    private NotificationAdapter categoryAdapter;
    private LinearLayoutManager linearLayoutManager;
    private RecyclerView rv;
    private ProgressDialog progressDialog;
    private boolean isLoading = false;
    private boolean isLastPage = false;
    // limiting to 5 for this tutorial, since total pages in actual API is very large. Feel free to modify.
    private int TOTAL_PAGES = 10;
    private int currentPage = PAGE_START;
    // private Retrofit retrofit;
    private ArrayList<Notification_details> trailersByCategory = new ArrayList<>();


    private List<Object> mRecyclerViewItems = new ArrayList<>();


    public FragmentNotification() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_profile_category, container, false);

        setData();
        return rootView;
    }

    private void setData() {

        rv = (RecyclerView) rootView.findViewById(R.id.recycler_categoryTrailers);

//        linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
//        rv.setLayoutManager(linearLayoutManager);

        mLayoutManager = new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL);
        mLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(mLayoutManager);
        rv.setItemAnimator(new DefaultItemAnimator());
        trailersByCategory.add(new Notification_details("LOREM IPSUM", "No one should have to worry about their messages being intercepted and read by the government, even if that message is “lo.” That’s why we joined @ACLU in challenging the NSA’s upstream surveillance practices "));
        trailersByCategory.add(new Notification_details("LOREM IPSUM DOLOR SIT AMET", "In October 1963, a black and white Parisian stray cat named Félicette became the first cat launched into space. Her flight lasted fifteen minutes, reaching a height of 156 kilometres. The cat was recovered safely after the capsule parachuted to Earth. "));
        trailersByCategory.add(new Notification_details("LOREM", " We believe that everyone, everywhere should have access to knowledge, which is why we are proud to announce on this #InternetDay that we’ve joined @theGNI as an observer:"));
        trailersByCategory.add(new Notification_details("LOREM IPSUM DOLOR ", "In October 1963, a black and white Parisian stray cat named Félicette became the first cat launched into space. Her flight lasted fifteen minutes, reaching a height of 156 kilometres. The cat was recovered safely after the capsule parachuted to Earth. "));
        trailersByCategory.add(new Notification_details("SIT AMET", "We believe that everyone, everywhere should have access to knowledge, which is why we are proud to announce on this #InternetDay that we’ve joined @theGNI as an observer:"));
        categoryAdapter = new NotificationAdapter(getActivity(), trailersByCategory);
        rv.setAdapter(categoryAdapter);
    }

}
