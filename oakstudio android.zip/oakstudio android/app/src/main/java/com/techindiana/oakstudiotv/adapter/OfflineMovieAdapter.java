package com.techindiana.oakstudiotv.adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.exoplayer2.offline.DownloadAction;
import com.google.android.exoplayer2.offline.DownloadService;
import com.google.android.exoplayer2.source.hls.offline.HlsDownloadAction;
import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.activity.DemoDownloadService;
import com.techindiana.oakstudiotv.activity.DownloadTracker;
import com.techindiana.oakstudiotv.activity.MovieDetailsActivity;
import com.techindiana.oakstudiotv.model.DownloadedMovieDetails;
import com.techindiana.oakstudiotv.model.VideoDTO;
import com.techindiana.oakstudiotv.utils.AppSession;
import com.techindiana.oakstudiotv.utils.OnItemClickListner;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by Rahul Patil on 23-Apr-18.
 */

public class OfflineMovieAdapter extends RecyclerView.Adapter<OfflineMovieAdapter.ItemRowHolder> {
    private static LayoutInflater inflater = null;
    Context mContext;
    Context context;
    Animation animation;

    public static String itemTypeId = "";
    private ArrayList<VideoDTO> list;
    private OnItemClickListner.OnClickCallback onClickCallback;
    AppSession appSession;
    String strListDate = "", delete = "";
    int removePosition = -1;

    public OfflineMovieAdapter(Context mContext, Context context, ArrayList<VideoDTO> list, OnItemClickListner.OnClickCallback onClickCallback) {
        this.mContext = mContext;
        this.context = context;
        this.list = list;
        this.onClickCallback = onClickCallback;
        appSession = AppSession.getInstance(context);

    }

    @Override
    public ItemRowHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        viewHolder = getViewHolder(viewGroup, inflater);
        return (ItemRowHolder) viewHolder;
    }

    @NonNull
    private RecyclerView.ViewHolder getViewHolder(ViewGroup parent, LayoutInflater inflater) {
        RecyclerView.ViewHolder viewHolder;
        View v1 = inflater.inflate(R.layout.item_offline_downloaded_movie, parent, false);
        viewHolder = new ItemRowHolder(v1);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ItemRowHolder viewHolder, int position) {
        VideoDTO dto = list.get(position);
        if (dto != null) {
        /*  //  viewHolder.tvTitle.setText(dto.getVideoUrl());
            viewHolder.movieName.setText(String.valueOf(dto.getMovieName()));
            viewHolder.tv_views.setText(String.valueOf(dto.getMovieViews()));
            viewHolder.movieYear.setText(String.valueOf(dto.getMovieYear()));
            viewHolder.movieRating.setText(String.valueOf(dto.getMovieRating()));
            viewHolder.tv_uploadDate.setText(String.valueOf(dto.getUploadedDate()));
            viewHolder.tv_remDays.setText(String.valueOf(dto.getRemaningDays()));
            viewHolder.movieImage.setImageResource(dto.getImage());
            //itemTypeId=movieDetailsArrayList.get(position).getId();
            viewHolder.movieImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mContext.startActivity(new Intent(mContext, MovieDetailsActivity.class));
                }
            });*/


            viewHolder.movieImage.setOnClickListener(new OnItemClickListner(position, onClickCallback, "play"));
            viewHolder.movieImage.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    delete = list.get(position).getVideoUrl();
                    removePosition = position;
                    dialogConfirm(context.getResources().getString(R.string.are_you_sure_you_want_to_remove_this_video));
                    System.out.println("LongClick: " + removePosition);
                    return true;// returning true instead of false, works for me
                }
            });
            viewHolder.movieName.setText("EXPANDABLE 2");
            viewHolder.tv_views.setText("" + 123);
            viewHolder.movieYear.setText("(2016)");
            viewHolder.movieRating.setText("" + 4.0);
            strListDate = dto.getDate();
            Calendar c = Calendar.getInstance();
            viewHolder.tv_uploadDate.setText("Uploaded" + " " + strListDate);

            Calendar startDate = Calendar.getInstance();
            int mYear = startDate.get(Calendar.YEAR);
            int mMonth = startDate.get(Calendar.MONTH)+1;
            int mDay = startDate.get(Calendar.DAY_OF_MONTH) ;
            startDate.set(mYear, mMonth, mDay);
            long startDateMillis = startDate.getTimeInMillis();

            if (dto.getDate_time()!=null){
                long differenceMillis = dto.getDate_time() - startDateMillis;
                int daysDifference = (int) (differenceMillis / (1000 * 60 * 60 * 24));
                viewHolder.tv_remDays.setText("Days left: "+String.valueOf(daysDifference));
            }


        }
    }

    @Override
    public int getItemCount(){
            return (null != list ? list.size() : 0);
    }

    class ItemRowHolder extends RecyclerView.ViewHolder {
        TextView movieName, movieYear, movieRating, tv_views, tv_uploadDate, tv_remDays;
        ImageView movieImage;

        ItemRowHolder(View view) {
            super(view);

            RatingBar ratingBar = (RatingBar) view.findViewById(R.id.ratingBar);
            Drawable drawable = ratingBar.getProgressDrawable();
            drawable.setColorFilter(Color.parseColor("#FEF400"), PorterDuff.Mode.SRC_ATOP);
            this.movieName = (TextView) view.findViewById(R.id.movieName);
            this.movieYear = (TextView) view.findViewById(R.id.movieYear);
            this.movieRating = (TextView) view.findViewById(R.id.movieRating);
            this.tv_views = (TextView) view.findViewById(R.id.tv_views);
            this.tv_uploadDate = (TextView) view.findViewById(R.id.tv_uploadDate);
            this.tv_remDays = (TextView) view.findViewById(R.id.tv_remDays);
            this.movieImage = (ImageView) view.findViewById(R.id.movieImage);
        }
    }

    public long returnDays(String startDate, String endDate) {
        long days = 0;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
//            LocalDate  start = LocalDate.parse("2/3/2017",formatter);
//            LocalDate  end = LocalDate.parse("3/3/2017",formatter);

            LocalDate start = LocalDate.parse(startDate, formatter);
            LocalDate end = LocalDate.parse(endDate, formatter);
            //  System.out.println(ChronoUnit.DAYS.between(start, end)); // 28
            System.out.println(ChronoUnit.DAYS.between(end, start)); // 28
            // Log.i(String.valueOf(this), "@@@@@@@@@@@@@@@ :"+ChronoUnit.DAYS.between(start, end)); // 28
            days = ChronoUnit.DAYS.between(start, end);
        }
        return days;

    }

    public void dialogConfirm(String message) {
        final Dialog dialog = new Dialog(context);
        Window window = dialog.getWindow();
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_box_yes_no);
        window.setType(WindowManager.LayoutParams.FIRST_SUB_WINDOW);
        window.setLayout(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        TextView tv_title = (TextView) window.findViewById(R.id.tv_title);
        tv_title.setText(context.getString(R.string.confirm));
        TextView tv_message = (TextView) window.findViewById(R.id.tv_message);
        tv_message.setText(Html.fromHtml("" + message));
        tv_message.setMovementMethod(new ScrollingMovementMethod());
        window.findViewById(R.id.tv_no).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        window.findViewById(R.id.tv_yes).setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (appSession != null) {
                    Toast.makeText(context, "removePosition " + removePosition, Toast.LENGTH_LONG).show();
                    list.remove(removePosition);

                    DownloadAction downloadAction = HlsDownloadAction.createRemoveAction(Uri.parse(delete), null);
                    DownloadService.startWithAction(context, DemoDownloadService.class, downloadAction, true);
                    appSession.setOfflineDownloadList(list);
                    if (appSession.getOfflineDownloadList() != null && appSession.getOfflineDownloadList().size() < 1) {
                        Toast.makeText(context, "NO OFFLINE DOWNLOADED VIDEO", Toast.LENGTH_LONG).show();
                    }
                }
                notifyDataSetChanged();
                dialog.dismiss();
            }
        });
        dialog.show();
    }
}
