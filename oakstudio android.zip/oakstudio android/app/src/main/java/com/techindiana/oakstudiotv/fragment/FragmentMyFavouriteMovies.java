package com.techindiana.oakstudiotv.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.adapter.MyFavourite_Movies_Adapter;
import com.techindiana.oakstudiotv.model.MyFavourite_MovieDetails;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentMyFavouriteMovies extends Fragment {
    private View rootView;
    private MyFavourite_Movies_Adapter myFavouriteMoviesAdapter;
    private LinearLayoutManager linearLayoutManager;
    StaggeredGridLayoutManager mLayoutManager;
    private RecyclerView rv;
    private ArrayList<MyFavourite_MovieDetails> myFavourite_movieDetailsArrayList = new ArrayList<>();

    public FragmentMyFavouriteMovies() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView= inflater.inflate(R.layout.fragment_fragment_my_favourite_movies, container, false);
       setData();
        return  rootView;
    }

    private void setData() {
        rv = (RecyclerView) rootView.findViewById(R.id.recycler_myFavouriteMovies);
        mLayoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        mLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(mLayoutManager);
        rv.setItemAnimator(new DefaultItemAnimator());



        myFavourite_movieDetailsArrayList.add(new MyFavourite_MovieDetails(R.drawable.view1,"ANT-MAN","(2016)",3,123));
        myFavourite_movieDetailsArrayList.add(new MyFavourite_MovieDetails(R.drawable.view2,"JUSTICE LEAGUE","(2016)",4,1021));
        myFavourite_movieDetailsArrayList.add(new MyFavourite_MovieDetails(R.drawable.view3,"BLACK PANTHER","(2016)",5,500));
        myFavourite_movieDetailsArrayList.add(new MyFavourite_MovieDetails(R.drawable.view4,"MISSION IMPOSSIBLE","(2016)",3,123));
        myFavourite_movieDetailsArrayList.add(new MyFavourite_MovieDetails(R.drawable.view,"EXPANDABLES 2","(2016)",5,854));
        myFavouriteMoviesAdapter = new MyFavourite_Movies_Adapter(getActivity(),myFavourite_movieDetailsArrayList);
        rv.setAdapter(myFavouriteMoviesAdapter);
    }

}
