package com.techindiana.oakstudiotv.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.google.gson.Gson;
import com.techindiana.oakstudiotv.R;

import com.techindiana.oakstudiotv.dto.PlaybackDTO;
import com.techindiana.oakstudiotv.model.VideoDTO;
import com.techindiana.oakstudiotv.utils.AppSession;
import com.techindiana.oakstudiotv.utils.DatabaseHelperPlayBack;

import java.util.ArrayList;
import java.util.HashMap;


public class ButtonActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btnBasic, btnStandard, btnPre;
    private Context mContext;
    private ImageView iv_tabback;
    ArrayList<VideoDTO> videoList;
    private AppSession appSession;
    private DatabaseHelperPlayBack databaseHelperPlayBack;
    private ArrayList<PlaybackDTO> playBackList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.button_activity);
        appSession = AppSession.getInstance(getApplicationContext());
//        if(videoList!=null){
//            videoList.clear();
//
//        }
        initialize();
    }

    private void initialize() {
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);
        btnBasic = (Button) findViewById(R.id.btn_basic);
        btnBasic.setOnClickListener(this);
        btnStandard = (Button) findViewById(R.id.btn_standard);
        btnStandard.setOnClickListener(this);
        btnPre = (Button) findViewById(R.id.btn_premium);
        btnPre.setOnClickListener(this);

        iv_tabback = (ImageView) findViewById(R.id.iv_tabback);
        iv_tabback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //String videoUrlSimple =  "https://sdaemonazuremedia-inct.streaming.media.azure.net/28eb6791-58b6-4ef8-a086-a1d807164e21/AQUAMAN.ism/manifest(format=m3u8-aapl).m3u8";

        //  String videoUrlSimple =  "https://nanomediaservices-inct.streaming.media.azure.net/f7f59c2b-3364-4d0a-a025-dfb10255a1d6/AQUAMAN.ism/manifest(format=m3u8-aapl).m3u8";
          String videoUrlSimple =  "https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8";
        //  String videoUrlSimple =  "https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8";
        //  String videoUrlSimple =  "http://184.72.239.149/vod/smil:BigBuckBunny.smil/playlist.m3u8";


        //  String videoUrlSimple =  "https://nanomediaservices-inct.streaming.media.azure.net/f7f59c2b-3364-4d0a-a025-dfb10255a1d6/AQUAMAN.ism/manifest(format=m3u8-aapl).m3u8";

        //  String videoUrlSimple = "https://oakstudio-usso.streaming.media.azure.net/a79335cb-eb85-4a24-9a8c-824abf3325af/BigBuckBunny.ism/manifest(format=m3u8-aapl).m3u8";
        //  String videoUrlSimple = "https://oakstudio-usso.streaming.media.azure.net/f377460d-95e9-4f25-9330-12880d6ad31b/BigBuckBunny.ism/manifest(format=m3u8-aapl).m3u8";


      //   String videoUrlSimple =  "https://bitdash-a.akamaihd.net/content/sintel/hls/playlist.m3u8"; // 5
        //    String videoUrlSimple =  "https://oakstudio-usso.streaming.media.azure.net/c5868280-b45a-41bc-adde-478afa6ccae7/BigBuckBunny.ism/manifest(format=m3u8-aapl)"; // 5

        //    String videoUrlSimple = "https://oakstudio-usso.streaming.media.azure.net/c5868280-b45a-41bc-adde-478afa6ccae7/BigBuckBunny.ism/manifest(format=m3u8-aapl).m3u8"; // 5


       //  String videoUrlSimple =  "https://oakstudio-usso.streaming.media.azure.net/442322e0-c52f-4ce5-8895-4cada54ff1d5/BigBuckBunny.ism/manifest(format=m3u8-aapl).m3u8";
      //   String videoUrlSimple =  "https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8";
       //  String videoUrlSimple =  "https://mnmedias.api.telequebec.tv/m3u8/29880.m3u8";
      //  String videoUrlSimple ="https://oakstudio-usso.streaming.media.azure.net/54b02c2f-b915-4632-a942-de2edf568ac3/BigBuckBunny.ism/manifest(format=m3u8-aapl).m3u8";
         String videoUrlMultiAdudio = "https://amssamples.streaming.mediaservices.windows.net/55034fb3-11af-43e4-a4de-d1b3ca56c5aa/ElephantsDream_MultiAudio.ism/manifest(format=m3u8-aapl).m3u8";
        videoList = new ArrayList<>();
        videoList.add(new VideoDTO(videoUrlSimple));
        //videoList.add(new VideoDTO(videoUrlMultiAdudio));
        //  videoList.add(new VideoDTO(videoUrlSimple));
        Log.i(String.valueOf(ButtonActivity.this), "========= VIDEO LIST SIZE : " + videoList.size());

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        invalidateOptionsMenu();
        menu.findItem(R.id.action_like).setVisible(true);
        menu.findItem(R.id.action_share).setVisible(true);
        menu.findItem(R.id.action_tuneUp).setVisible(false);
        menu.findItem(R.id.action_person).setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_like) {
            return true;
        }
        if (id == R.id.action_share) {
            return true;
        }
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_basic:
                databaseHelperPlayBack = new DatabaseHelperPlayBack(this);
                playBackList = databaseHelperPlayBack.getAllTeachers();
                Log.i(String.valueOf(ButtonActivity.this), "========= playBackList : " + playBackList.size());
                String playBackPosition = "0";
                for (int i = 0; i < playBackList.size(); i++) {
                    Log.i(String.valueOf(ButtonActivity.this), "=========URL : " + playBackList.get(i).getUrlId());
                    Log.i(String.valueOf(ButtonActivity.this), "=========URL ID : " + playBackList.get(i).getPlayBackPosition());

                    if ("Rajendra".equalsIgnoreCase(playBackList.get(i).getUrlId())) {
                        //  Toast.makeText(ButtonActivity.this, " if"+playBackList.get(i).getPlayBackPosition(), Toast.LENGTH_SHORT).show();
                        playBackPosition = playBackList.get(i).getPlayBackPosition();
                    } else {
                        //  Toast.makeText(ButtonActivity.this, "else"+playBackList.get(i).getPlayBackPosition(), Toast.LENGTH_SHORT).show();
                        playBackPosition = "0";
                    }

                }
                Intent intent = new Intent(ButtonActivity.this, Rajendra.class);
                Bundle bundle = new Bundle();
                bundle.putString("TYPE", "");
                bundle.putString("PLAYBACK_POSITION", playBackPosition);
                bundle.putString("PN_JSON_OBJECT", new Gson().toJson(videoList));
                intent.putExtras(bundle);
                startActivity(intent);
                break;
            case R.id.btn_standard:
                break;
            case R.id.btn_premium:
                intent = new Intent(ButtonActivity.this, OffLineDownloadListActivity.class);
                startActivity(intent);

                //  databaseHelperTeacher = new DatabaseHelperPlayBack(this);
//                teachersModelArrayList = databaseHelperTeacher.getAllTeachers();
//
//                Log.i(String.valueOf(ButtonActivity.this),"========= teachersModelArrayList : "+teachersModelArrayList.size());
//                for (int i = 0; i <teachersModelArrayList.size() ; i++) {
//                    Log.i(String.valueOf(ButtonActivity.this),"=========URL : "+teachersModelArrayList.get(i).getUrlId());
//                    Log.i(String.valueOf(ButtonActivity.this),"=========URL ID : "+teachersModelArrayList.get(i).getPlayBackPosition());
//
//                    if("Rajendra".equalsIgnoreCase(teachersModelArrayList.get(i).getUrlId())){
//                        Toast.makeText(ButtonActivity.this, " if"+teachersModelArrayList.get(i).getPlayBackPosition(), Toast.LENGTH_SHORT).show();
//                    }
//                    else {
//                        Toast.makeText(ButtonActivity.this, "else"+teachersModelArrayList.get(i).getPlayBackPosition(), Toast.LENGTH_SHORT).show();
//                    }
//
//                }

                break;
        }
    }


}
