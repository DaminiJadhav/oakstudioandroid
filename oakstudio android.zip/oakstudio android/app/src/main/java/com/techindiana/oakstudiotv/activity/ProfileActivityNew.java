package com.techindiana.oakstudiotv.activity;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.fragment.FragmentAccountSetting;
import com.techindiana.oakstudiotv.fragment.FragmentBalance_details;
import com.techindiana.oakstudiotv.fragment.FragmentMyFavouriteMovies;
import com.techindiana.oakstudiotv.fragment.FragmentMyFavouriteNew;
import com.techindiana.oakstudiotv.fragment.FragmentNotification;
import com.techindiana.oakstudiotv.fragment.FragmentOffLineDownload;
import com.techindiana.oakstudiotv.fragment.FragmentPayment_details;
import com.techindiana.oakstudiotv.fragment.FragmentYourPlanAPI;
import com.techindiana.oakstudiotv.model.Profile_categories;

import java.util.ArrayList;
import java.util.List;

public class ProfileActivityNew extends AppCompatActivity {

    private Context mContext;
    private ArrayList<Profile_categories> profile_categories = new ArrayList<>();
    private ImageView iv_tabback;
    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        initialization();
    }

    private void initialization() {
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);
        iv_tabback = (ImageView) findViewById(R.id.iv_tabback);
        iv_tabback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.tab_viewpager);


        tabLayout.addTab(tabLayout.newTab().setText(""));
        TabLayout.Tab tab = tabLayout.getTabAt(0);
        tab.setIcon(R.mipmap.bell);
        tabLayout.addTab(tabLayout.newTab().setText("ACCOUNT SETTING"));
        tabLayout.addTab(tabLayout.newTab().setText("PAYMENT DETAILS"));
        tabLayout.addTab(tabLayout.newTab().setText("BALANCE DETAILS"));
        tabLayout.addTab(tabLayout.newTab().setText("YOUR PLAN"));

//        if (viewPager != null) {
//            setupViewPager(viewPager);
//        }
//        tabLayout.setupWithViewPager(viewPager);
//        TabLayout.Tab tab = tabLayout.getTabAt(0);
//        tab.setIcon(R.mipmap.bell);

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        //   MyAdapter adapter = new MyAdapter(context, getActivity().getSupportFragmentManager(), tabLayout.getTabCount());
        ProfileActivityNew.MyAdapter adapter = new ProfileActivityNew.MyAdapter(this, getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }


    public class MyAdapter extends FragmentPagerAdapter {
        private Context myContext;
        int totalTabs;

        public MyAdapter(Context context, FragmentManager fm, int totalTabs) {
            super(fm);
            myContext = context;
            this.totalTabs = totalTabs;
        }

        // this is for fragment tabs
        @Override
        public Fragment getItem(int position) {

            switch (position) {
                case 0:
                    FragmentNotification fragmentNotification = new FragmentNotification();
                    return fragmentNotification;
                case 1:
                    FragmentAccountSetting fragmentAccountSetting = new FragmentAccountSetting();
                    return fragmentAccountSetting;
                case 2:
                    FragmentPayment_details fragmentPayment_details = new FragmentPayment_details("");
                    return fragmentPayment_details;

                case 3:
                    FragmentBalance_details fragmentBalanceDetails = new FragmentBalance_details();
                    return fragmentBalanceDetails;
                case 4:
                    //  FragmentYourPlan()
                    FragmentYourPlanAPI fragmentYourPlanAPI = new FragmentYourPlanAPI();
                    return fragmentYourPlanAPI;


                default:
                    return null;
            }
        }// this counts total number of tabs

        @Override
        public int getCount() {
            return totalTabs;
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        invalidateOptionsMenu();
        menu.findItem(R.id.action_like).setVisible(false);
        menu.findItem(R.id.action_share).setVisible(false);
        menu.findItem(R.id.action_tuneUp).setVisible(false);
        menu.findItem(R.id.action_person).setVisible(false);
        menu.findItem(R.id.action_done).setVisible(true);
        return super.onPrepareOptionsMenu(menu);
    }
}
