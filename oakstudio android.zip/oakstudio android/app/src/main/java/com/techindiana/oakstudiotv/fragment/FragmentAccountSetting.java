package com.techindiana.oakstudiotv.fragment;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.activity.ChangeAccountPassActivity;
import com.techindiana.oakstudiotv.activity.CheckInternetSpeedActivity;
import com.techindiana.oakstudiotv.activity.ChooseShareActivity;
import com.techindiana.oakstudiotv.activity.CommunicationPrefActivity;
import com.techindiana.oakstudiotv.activity.SelectLanguageActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentAccountSetting extends Fragment implements View.OnClickListener {
    private static final String TAG = "TasksSample";
    public  long startTime;
    public   long endTime;
    public  long fileSize;
    // bandwidth in kbps
    public  int POOR_BANDWIDTH = 150;
    public int AVERAGE_BANDWIDTH = 550;
    public  int GOOD_BANDWIDTH = 2000;
    private View rootView;
    private TextView tv_changePass,tv_language,tv_comunicationPref,tv_chooseShare;
    Button btn_speedtest1;
    private Context mContext;

    public FragmentAccountSetting() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView= inflater.inflate(R.layout.fragment_fragment_account_setting, container, false);
        mContext=getContext();
        intitialization();
        return rootView;
    }

    private void intitialization() {

        tv_changePass=(TextView)rootView.findViewById(R.id.tv_changePass);
        tv_language=(TextView)rootView.findViewById(R.id.tv_language);
        tv_comunicationPref=(TextView)rootView.findViewById(R.id.tv_comunicationPref);
        tv_chooseShare=(TextView)rootView.findViewById(R.id.tv_chooseShare);
        btn_speedtest1=rootView.findViewById(R.id.btn_speedtest);
        final TextView occupiedSpaceText = (TextView)rootView.findViewById(R.id.occupiedSpace);
        final TextView freeSpaceText = (TextView)rootView.findViewById(R.id.freeSpace);
        final ProgressBar progressIndicator = (ProgressBar)rootView.findViewById(R.id.indicator);
        final float totalSpace = DeviceMemory.getInternalStorageSpace();
        final float occupiedSpace = DeviceMemory.getInternalUsedSpace();
        final float freeSpace = DeviceMemory.getInternalFreeSpace();
        final DecimalFormat outputFormat = new DecimalFormat("#.##");




        tv_changePass.setOnClickListener(this);
        tv_language.setOnClickListener(this);
        tv_comunicationPref.setOnClickListener(this);
        tv_chooseShare.setOnClickListener(this);
        btn_speedtest1.setOnClickListener(this);


        if (null != occupiedSpaceText) {
            occupiedSpaceText.setText(outputFormat.format(occupiedSpace) + " MB");
        }

        if (null != freeSpaceText) {
            freeSpaceText.setText(outputFormat.format(freeSpace) + " MB");
        }

        if (null != progressIndicator) {
            progressIndicator.setMax((int) totalSpace);
            progressIndicator.setProgress((int)occupiedSpace);
        }


    }



    public static class DeviceMemory {

        public static float getInternalStorageSpace() {
            StatFs statFs = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            //StatFs statFs = new StatFs("/data");
            float total = ((float)statFs.getBlockCount() * statFs.getBlockSize()) / 1048576;
            return total;
        }

        public static float getInternalFreeSpace() {
            StatFs statFs = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            //StatFs statFs = new StatFs("/data");
            float free  = ((float)statFs.getAvailableBlocks() * statFs.getBlockSize()) / 1048576;
            return free;
        }

        public static float getInternalUsedSpace() {
            StatFs statFs = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            //StatFs statFs = new StatFs("/data");
            float total = ((float)statFs.getBlockCount() * statFs.getBlockSize()) / 1048576;
            float free  = ((float)statFs.getAvailableBlocks() * statFs.getBlockSize()) / 1048576;
            float busy  = total - free;
            return busy;
        }
    }

    public void checkSpeedTest()
    {

        ConnectivityManager connectivityManager= (ConnectivityManager) getActivity().getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
        if (networkInfo!=null && networkInfo.isConnected()==true)
        {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url("https://homepages.cae.wisc.edu/~ece533/images/airplane.png")    .build();

            startTime = System.currentTimeMillis();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);
                    Headers responseHeaders = response.headers();
                    for (int i = 0, size = responseHeaders.size(); i < size; i++) {
                        Log.d(TAG, responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }
                    InputStream input = response.body().byteStream();
                    try {
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buffer = new byte[1024];
                        while (input.read(buffer) != -1) {
                            bos.write(buffer);
                        }
                        byte[] docBuffer = bos.toByteArray();
                        fileSize = bos.size();
                    } finally {
                        input.close();
                    }
                    endTime = System.currentTimeMillis();
                    // calculate how long it took by subtracting endtime from starttime
                    double timeTakenMills = Math.floor(endTime - startTime);  // time taken in milliseconds
                    double timeTakenSecs = timeTakenMills / 1000;  // divide by 1000 to get time in seconds
                    final int kilobytePerSec = (int) Math.round(1024 / timeTakenSecs);
                    if(kilobytePerSec <= POOR_BANDWIDTH){
                        // slow connection
                    }
                    // get the download speed by dividing the file size by time taken to download
                    double speed = fileSize / timeTakenMills;
                    Log.d(TAG, "Time taken in secs: " + timeTakenSecs);
                    Log.d(TAG, "kilobyte per sec: " + kilobytePerSec);
                    Log.d(TAG, "Download Speed: " + speed);
                    Log.d(TAG, "File size: " + fileSize);
                }
            });


        }
        else {
            Toast.makeText(mContext, "Network Not Available", Toast.LENGTH_SHORT).show();
        }

    }






    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.tv_changePass:
                Intent i = new Intent(getActivity(), ChangeAccountPassActivity.class);
                startActivity(i);
                ((Activity) getActivity()).overridePendingTransition(0,0);

                break;

            case R.id.tv_language:

                Intent intent = new Intent(getActivity(), SelectLanguageActivity.class);
                startActivity(intent);
                ((Activity) getActivity()).overridePendingTransition(0,0);

                break;

            case R.id.tv_comunicationPref:

                Intent intent1 = new Intent(getActivity(), CommunicationPrefActivity.class);
                startActivity(intent1);
                ((Activity) getActivity()).overridePendingTransition(0,0);

                break;

            case R.id.tv_chooseShare:

                Intent intent2 = new Intent(getActivity(), ChooseShareActivity.class);
                startActivity(intent2);
                ((Activity) getActivity()).overridePendingTransition(0,0);

                break;

          case R.id.btn_speedtest:
//              checkSpeedTest();
              Intent intent3=new Intent(mContext, CheckInternetSpeedActivity.class);
              startActivity(intent3);
              ((getActivity())).overridePendingTransition(0, 0);

              break;

        }
    }




}

