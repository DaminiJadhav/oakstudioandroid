package com.techindiana.oakstudiotv.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.techindiana.oakstudiotv.activity.AboutUsActivity;
import com.techindiana.oakstudiotv.dto.BaseUrlDTO;
import com.techindiana.oakstudiotv.dto.ContentDTO;
import com.techindiana.oakstudiotv.dto.FilterDTO;
import com.techindiana.oakstudiotv.dto.NationalParkDTO;
import com.techindiana.oakstudiotv.dto.UserDTO;
import com.techindiana.oakstudiotv.dto.UserStatusDTO;
import com.techindiana.oakstudiotv.dto.UsersDTO;
import com.techindiana.oakstudiotv.model.AboutUsResponse;
import com.techindiana.oakstudiotv.model.VideoDTO;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
public class AppSession {
    private static final String APP_DEFAULT_LANGUAGE = "en";
    private static SharedPreferences sharedPref;
    private static Editor editor;
    private static AppSession appSession = null;
    public static AppSession getInstance(Context context) {
        if (appSession == null) {
            appSession = new AppSession();
            try {
                sharedPref = context.getSharedPreferences(context.getPackageName() + ".AppSession", Context.MODE_PRIVATE);
                editor = sharedPref.edit();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return appSession;
    }

     //////// START SESSION FOR LOGIN CREDENTIALS //////////////////

   public void setOfflineDownloadList(List<VideoDTO> list) {
        Gson gson = new Gson();
        String jsonList = gson.toJson(list);
        editor.putString("getOfflineDownloadList", jsonList);
        editor.commit();
    }

    public ArrayList<VideoDTO> getOfflineDownloadList() {
        ArrayList<VideoDTO> id = new ArrayList<VideoDTO>();
        try {
            String userJSONString = sharedPref.getString("getOfflineDownloadList", null);
            if (userJSONString == null)
                return id;
            Type type = new TypeToken<ArrayList<VideoDTO>>() {
            }.getType();
            id = new Gson().fromJson(userJSONString, type);
            return id;
        } catch (Exception e) {
            e.printStackTrace();
            return id;
        }
    }


    public void setUserStatusList(List<UserStatusDTO.Result> list) {
        Gson gson = new Gson();
        String jsonList = gson.toJson(list);
        editor.putString("getUserStatusList", jsonList);
        editor.commit();
    }

    public ArrayList<UserStatusDTO.Result> getUserStatusList() {
        ArrayList<UserStatusDTO.Result> id = new ArrayList<UserStatusDTO.Result>();
        try {
            String userJSONString = sharedPref.getString("getUserStatusList", null);
            if (userJSONString == null)
                return id;
            Type type = new TypeToken<ArrayList<UserStatusDTO.Result>>() {
            }.getType();
            id = new Gson().fromJson(userJSONString, type);
            return id;
        } catch (Exception e) {
            e.printStackTrace();
            return id;
        }
    }












//Filtre

    public void setFilterList(List<FilterDTO> list) {
        Gson gson = new Gson();
        String jsonList = gson.toJson(list);
        editor.putString("getFilterList", jsonList);
        editor.commit();
    }

    public ArrayList<FilterDTO> getFilterList() {
        ArrayList<FilterDTO> id = new ArrayList<FilterDTO>();
        try {
            String userJSONString = sharedPref.getString("getFilterList", null);
            if (userJSONString == null)
                return id;
            Type type = new TypeToken<ArrayList<FilterDTO>>() {
            }.getType();
            id = new Gson().fromJson(userJSONString, type);
            return id;
        } catch (Exception e) {
            e.printStackTrace();
            return id;
        }
    }

    public void setOfflineDate(String date) {
        editor.putString("getDate", date);
        editor.commit();
    }

    public String getOfflineDate() {
        return sharedPref.getString("getDate", "");
    }



    //MovieDetails

    public void setMovieDetail(ContentDTO contentDTO) {
        editor.putString("getMovieDetail", new Gson().toJson(contentDTO));
        editor.commit();
    }

    public ContentDTO getMovieDetail() {
        try {
            String movieJSONString = sharedPref.getString("getMovieDetail", null);
            if (movieJSONString == null)
                return null;
            Type type = new TypeToken<ContentDTO>() {
            }.getType();
            ContentDTO contentDTO= new Gson().fromJson(movieJSONString, type);
            return contentDTO;
        } catch (NullPointerException e) {
            e.printStackTrace();
            return new ContentDTO();
        }
    }



    // Genre ID


  public void setGenreID(String GenreID) {
        editor.putString("getGenreID", GenreID);
        editor.commit();
    }

    public String getGenreID() {
        return sharedPref.getString("getGenreID", "");
    }

    public Integer getGenreIDposition() {
        return sharedPref.getInt("getGenreIDposition", 0);
    }

    public void setGenreIDposition(int Position) {
        editor = sharedPref.edit();
        editor.putInt("getGenreIDposition", Position);
        editor.commit();
    }

   //Review ID


    public void setReviewID(String yearID) {
        editor.putString("getReviewID", yearID);
        editor.commit();
    }

    public String getReviewID() {
        return sharedPref.getString("getReviewID", "");
    }

    public Integer getReviewIDposition() {
        return sharedPref.getInt("getReviewIdposition", 1);
    }

    public void setReviewIDposition(int Position) {
        editor = sharedPref.edit();
        editor.putInt("getReviewIdposition", Position);
        editor.commit();
    }

    //Year ID


    public void setYearID(String yearID) {
        editor.putString("getYearID", yearID);
        editor.commit();
    }

    public String getYearID() {
        return sharedPref.getString("getYearID", "");
    }

    public Integer getYearIDposition() {
        return sharedPref.getInt("getYearIdposition", 1);
    }

    public void setYearIDposition(int Position) {
        editor = sharedPref.edit();
        editor.putInt("getYearIdposition", Position);
        editor.commit();
    }

    //Studio ID

    public void setStudioID(String studioID) {
        editor.putString("getStudioID", studioID);
        editor.commit();
    }

    public String getStudioID() {
        return sharedPref.getString("getStudioID", "");
    }

    public Integer getStudioIDposition() {
        return sharedPref.getInt("getStudioIdposition", 1);
    }

    public void setStudioIDposition(int Position) {
        editor = sharedPref.edit();
        editor.putInt("getStudioIdposition", Position);
        editor.commit();
    }


    //Feature ID

    public void setFeatureID(String studioID) {
        editor.putString("getFeatureID", studioID);
        editor.commit();
    }

    public String getFeatureID() {
        return sharedPref.getString("getFeatureID", "");
    }

    public Integer getFeatureIDposition() {
        return sharedPref.getInt("getFeatureIdposition", 1);
    }

    public void setFeatureIDposition(int Position) {
        editor = sharedPref.edit();
        editor.putInt("getFeatureIdposition", Position);
        editor.commit();
    }




//Rating ID

    public void setRatingID(String studioID) {
        editor.putString("getRatingID", studioID);
        editor.commit();
    }

    public String getRatingID() {
        return sharedPref.getString("getRatingID", "");
    }

    public Integer getRatingIDposition() {
        return sharedPref.getInt("getRatingIdposition", 1);
    }

    public void setRatingIDposition(int Position) {
        editor = sharedPref.edit();
        editor.putInt("getRatingIdposition", Position);
        editor.commit();
    }



    //About Us

    public void setAbout(List<AboutUsResponse> aboutUsResponse) {
        editor.putString("aboutUsData", new Gson().toJson(aboutUsResponse));
        editor.commit();
    }

    public List<AboutUsResponse> getAbout() {
        try {
            String userJSONString = sharedPref.getString("aboutUsData", null);
            if (userJSONString == null)
                return null;
            Type type = new TypeToken<List<AboutUsResponse>>() {
            }.getType();
            List<AboutUsResponse> aboutUsResponse = new Gson().fromJson(userJSONString, type);
            return aboutUsResponse;
        } catch (NullPointerException e) {
            e.printStackTrace();
            return new ArrayList<AboutUsResponse>();

        }
    }


//





    public Integer getPosition() {
        return sharedPref.getInt("Position", 0);
    }

    public void setPosition(int Position) {
        editor = sharedPref.edit();
        editor.putInt("Position", Position);
        editor.commit();
    }
    public ArrayList<NationalParkDTO> getNotificationList() {
        Gson gson = new Gson();
        String json = sharedPref.getString("NotificationList", null);
        Type type = new TypeToken<ArrayList<NationalParkDTO>>() {}.getType();
        ArrayList<NationalParkDTO> notificationList = new ArrayList<>();
        notificationList = gson.fromJson(json, type);
        return notificationList;
    }

    public void setNotificationList(ArrayList<NationalParkDTO> notificationList) {
        Gson gson = new Gson();
        String json = gson.toJson(notificationList);
        editor = sharedPref.edit();
        editor.putString("NotificationList", json);
        editor.commit();
    }


    public void setUrlDto(BaseUrlDTO urlDto){
        SharedPreferences.Editor editor = sharedPref.edit();
        Gson gson = new Gson();
        String urls = gson.toJson(urlDto);
        editor.putString("urls",urls);
        editor.commit();
//        Log.e(getClass().getName(),"data Save''''''''''''''''''''''''''");
    }

    public BaseUrlDTO getUrlDto (){
        BaseUrlDTO urlDto = new BaseUrlDTO();
        String urls = sharedPref.getString("urls",null);
        if (urlDto == null)
            return null;
        Gson gson = new Gson();
        urlDto = gson.fromJson(urls,BaseUrlDTO.class);
        return urlDto;
    }

    public void setUserDTO(UsersDTO userDTO) {
        editor.putString("userDTO", new Gson().toJson(userDTO));
        editor.commit();
    }

    public UsersDTO getUserDTO() {
        try {
            String userJSONString = sharedPref.getString("userDTO", null);
            if (userJSONString == null)
                return null;
            Type type = new TypeToken<UsersDTO>() {
            }.getType();
            UsersDTO dto = new Gson().fromJson(userJSONString, type);
            return dto;
        } catch (NullPointerException e) {
            e.printStackTrace();
            return new UsersDTO();
        }
    }

    public UsersDTO getUsersDTO(){
        Gson gson = new Gson();
        String result = sharedPref.getString("userDTO", null);
        UsersDTO usersDTO=new UsersDTO();
        if (result!=null)
        {
            Type listType = new TypeToken<UsersDTO>() {}.getType();
            usersDTO = gson.fromJson(result, listType);
        }
//        ArrayList<UsersDTO> list = new ArrayList<UsersDTO>();

        return usersDTO;
    }



}