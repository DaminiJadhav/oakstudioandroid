package com.techindiana.oakstudiotv.dao;

import com.techindiana.oakstudiotv.utils.AppConstants;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitBrainTreeClient {
    private static Retrofit retrofit;

    public static SdaemonApi sdaemonApi() {
        synchronized (Retrofit.class) {
            Retrofit.Builder rb = new Retrofit.Builder();
            rb.baseUrl(SdaemonApi.BASEPATH_BRAINTREE);
            rb.addConverterFactory(GsonConverterFactory.create());
            if(AppConstants.APP_DEBUGGER)
                rb.client(new OkHttpClient.Builder().addInterceptor(new LogJsonInterceptor()).build());
            retrofit = rb.build();
        }
        return  retrofit.create(SdaemonApi.class);
    }


}
