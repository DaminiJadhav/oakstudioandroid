package com.techindiana.oakstudiotv.activity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.dao.RetroClient;
import com.techindiana.oakstudiotv.dto.ContentDTO;
import com.techindiana.oakstudiotv.fragment.FragmentCreators_Cast;
import com.techindiana.oakstudiotv.fragment.FragmentMovieDetails_Info;
import com.techindiana.oakstudiotv.fragment.FragmentUserReviews;
import com.techindiana.oakstudiotv.model.CategoiesList;
import com.techindiana.oakstudiotv.model.ContentInfo;
import com.techindiana.oakstudiotv.model.MovieDetailsCategory;
import com.techindiana.oakstudiotv.model.ReviewsList;
import com.techindiana.oakstudiotv.utils.AppSession;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class MovieDetailsActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private ViewPager tabViewPager;
    private Context mContext;
    TextView tvfeatureDescription,tvviewCount,tvYear,tvavgRating;
    private RatingBar rateBar;
    private LinearLayout ll_ratingView;
    public List<ContentInfo> list;
    public List<CategoiesList> infoList;
    public List<ReviewsList> reviewsLists;

    private ArrayList<MovieDetailsCategory> movieDetailsCategories=new ArrayList<>();
    private ImageView iv_tabback,like;
    public Retrofit retrofit;
    AppSession appSession;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);
        tvfeatureDescription=findViewById(R.id.tv_featureDescription);
        tvviewCount=findViewById(R.id.tv_view);
        tvYear=findViewById(R.id.tv_year);
        tvavgRating=findViewById(R.id.movieRating);
        mContext=this;
        list=new ArrayList<>();
        infoList=new ArrayList<>();
        reviewsLists=new ArrayList<>();
        appSession=AppSession.getInstance(mContext);
        getAllMovieDetails();
//        initialize();
    }

    private void initialize() {
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);



        movieDetailsCategories.add(new MovieDetailsCategory("INFORMATION"));
        movieDetailsCategories.add(new MovieDetailsCategory("CREATORS & CAST"));
        movieDetailsCategories.add(new MovieDetailsCategory("USER REVIEWS"));


        tabViewPager = (ViewPager) findViewById(R.id.tab_viewpager);
       // ll_ratingView = (LinearLayout) findViewById(R.id.ll_ratingView);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        rateBar = (RatingBar) findViewById(R.id.rateBar);
//        like=findViewById(R.id.action_like);


        RatingBar rateBar = (RatingBar)findViewById(R.id.rateBar);
        Drawable drawable = rateBar.getProgressDrawable();
        drawable.setColorFilter(Color.parseColor("#FEF400"), PorterDuff.Mode.SRC_ATOP);

        if (tabViewPager != null) {
            setupViewPager(tabViewPager);
        }
        tabLayout.setupWithViewPager(tabViewPager);
        int limit = movieDetailsCategories.size();
        tabViewPager.setOffscreenPageLimit(limit);



        iv_tabback = (ImageView) findViewById(R.id.iv_tabback);
        iv_tabback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    public void getAllMovieDetails(){
        Call<ContentDTO> call= RetroClient.sdaemonApi().getAllMovieDetails("4",0);
        call.enqueue(new Callback<ContentDTO>() {
            @Override
            public void onResponse(Call<ContentDTO> call, Response<ContentDTO> response) {
                if (response.isSuccessful()){
                    ContentDTO contentDTO=response.body();
                    appSession.setMovieDetail(contentDTO);

                    Toast.makeText(MovieDetailsActivity.this, "Success", Toast.LENGTH_SHORT).show();
                    Log.i("MovieDetailsActivity","" +contentDTO);
//                    appSession.setMovieDetail(contentDTO);
                    list=contentDTO.getContentDetail().getContentInfos();
                    infoList=contentDTO.getContentDetail().getCategoiesList();
                    reviewsLists=contentDTO.getContentDetail().getReviewList();


                    tvfeatureDescription.setText(list.get(0).getFeaturesDescription());
                    tvviewCount.setText("" +list.get(0).getViewCount());
                    tvYear.setText(list.get(0).getYear().toString());
                    tvavgRating.setText("" +contentDTO.getContentDetail().getAvgRating().get(0).getAvgRating());
                    initialize();
//                    tabViewPager = (ViewPager) findViewById(R.id.tab_viewpager);
//                    // ll_ratingView = (LinearLayout) findViewById(R.id.ll_ratingView);
//                    tabLayout = (TabLayout) findViewById(R.id.tabLayout);


                }
            }

            @Override
            public void onFailure(Call<ContentDTO> call, Throwable t) {
                Log.i("MovieDetailsActivity","Fail" );
                Toast.makeText(MovieDetailsActivity.this, "" +t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }




    public void setupViewPager(ViewPager tabViewPager) {
         ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        int count = movieDetailsCategories.size();
        /*for (int i = 0; i < count; i++) {

        }*/

        adapter.addFrag(new FragmentMovieDetails_Info(list), movieDetailsCategories.get(0).getCategoryName());
        adapter.addFrag(new FragmentCreators_Cast(), movieDetailsCategories.get(1).getCategoryName());
        adapter.addFrag(new FragmentUserReviews(reviewsLists), movieDetailsCategories.get(2).getCategoryName());
        tabViewPager.setAdapter(adapter);
    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();
//        private final List<ContentInfo> t1 = new ArrayList<>();


        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment,String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        invalidateOptionsMenu();
        menu.findItem(R.id.action_like).setVisible(true);
        menu.findItem(R.id.action_share).setVisible(true);
        menu.findItem(R.id.action_tuneUp).setVisible(false);
        menu.findItem(R.id.action_person).setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_like) {
//            like.setBackgroundColor(Color.parseColor("#FF0000"));
            return true;
        }
        if (id == R.id.action_share) {
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            String shareSubText = "WhatsApp - The Great Chat App";
            String shareBodyText = "https://play.google.com/store/apps/details?id=com.whatsapp&hl=en";
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, shareSubText);
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareBodyText);
            startActivity(Intent.createChooser(shareIntent, "Share With"));

            return true;
        }
        if (id==android.R.id.home)
        {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }




}
