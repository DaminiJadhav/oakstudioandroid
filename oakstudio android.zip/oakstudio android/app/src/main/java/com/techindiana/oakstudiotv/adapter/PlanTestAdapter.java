package com.techindiana.oakstudiotv.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;

import com.techindiana.oakstudiotv.model.Datum;
import com.techindiana.oakstudiotv.utils.OnItemClickListner;

import java.util.List;

public class PlanTestAdapter {
    private List<Datum> list;
        private Context context;
        private OnItemClickListner.OnClickCallback onClickCallback;

        public PlanTestAdapter(Context context,List<Datum> list,  OnItemClickListner.OnClickCallback onClickCallback){
                this.context=context;
                this.list=list;
                this.onClickCallback=onClickCallback;
        }
}
