package com.techindiana.oakstudiotv.fragment;


import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.NavUtils;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.dynamic.IFragmentWrapper;
import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.activity.FilterActivity;
import com.techindiana.oakstudiotv.activity.GenreActivity;
import com.techindiana.oakstudiotv.model.Category;
import com.techindiana.oakstudiotv.model.MovieCategory_list;
import com.techindiana.oakstudiotv.retrofit_utils.RetrofitUtils;
import com.techindiana.oakstudiotv.retrofit_utils.restUtils.RestCallInterface;
import com.techindiana.oakstudiotv.utils.AppSession;
import com.techindiana.oakstudiotv.utils.Utilities;
import com.techindiana.oakstudiotv.viewpageradapter.MyAdapter;
import com.techindiana.oakstudiotv.viewpageradapter.MyPager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import me.relex.circleindicator.CircleIndicator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import static android.view.View.GONE;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentAll_Movies extends Fragment {
    private View rootView;
    private TabLayout tabLayout;
    private ViewPager tabViewPager,viewPager;
    private Retrofit retrofit;
    private Context mContext;
    private Integer images[]={R.drawable.banner,R.drawable.view,R.drawable.view1};
    private ArrayList<Integer> imagesArray = new ArrayList<Integer>();
    private static int currentPage = 0;
    private ArrayList<Category> movieCategory_lists = new ArrayList<>();
    private Toolbar toolbar;
    int position;
    private LinearLayout llMessageMain, llLoading,llscrollImages;
    private TextView tvRetry, tvMessage,tvcomedy,tvyear,tvreview,tvstudio,tvfeature,tvparam,tvrating;
    private ImageView ivapplyfilter;
    private CircleIndicator circleIndicator;
    AppSession appSession;
    MyPager myPager;
    MyAdapter myAdapter;
    Category category;
    Utilities utilities;
    public FragmentAll_Movies() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_fragment_all__movies, container, false);
        mContext=getContext();
        appSession=AppSession.getInstance(mContext);
      //  initialize();

//        scrollViewNewImages();
        return rootView;
    }
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext = getActivity();
        utilities = Utilities.getInstance(mContext);
        initialize();
        setViewPager();


//        showProgress();
        getValue();
    }


    private void initialize() {
        llMessageMain = rootView.findViewById(R.id.ll_message_main);
        llLoading = rootView.findViewById(R.id.ll_loading);
        llscrollImages=rootView.findViewById(R.id.ll_horizontalscrollview);
        viewPager=rootView.findViewById(R.id.ll_viewpager);
        circleIndicator=rootView.findViewById(R.id.circle);
//        ivmovie=rootView.findViewById(R.id.iv_movie);
        tvMessage = rootView.findViewById(R.id.tv_message);
        tvMessage.setMovementMethod(new ScrollingMovementMethod());
        tvRetry = rootView.findViewById(R.id.tv_retry);
        tvcomedy=rootView.findViewById(R.id.txt_comedy);
        tvyear=rootView.findViewById(R.id.txt_year);
        tvreview=rootView.findViewById(R.id.txt_review);
        tvstudio=rootView.findViewById(R.id.txt_studio);
        tvfeature=rootView.findViewById(R.id.txt_feature);
//        tvparam=rootView.findViewById(R.id.txt_param);
        tvrating=rootView.findViewById(R.id.txt_rating);
        ivapplyfilter=rootView.findViewById(R.id.iv_applyfilter);
        tvRetry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             getValue();
            }
        });

      //  retrofit = RetrofitUtils.getRetrofitWithoutHeader();
        RatingBar ratingBar = (RatingBar) rootView.findViewById(R.id.ratingBar);
        Drawable drawable = ratingBar.getProgressDrawable();
        drawable.setColorFilter(Color.parseColor("#FEF400"), PorterDuff.Mode.SRC_ATOP);

            if(textviewInvisible()) {

                if (appSession.getGenreID()==""  && appSession.getYearID()==""  && appSession.getReviewID()=="" && appSession.getStudioID()==""  && appSession.getFeatureID()==""  && appSession.getRatingID()=="" ){
                   textviewInvisible();
                }

               else if (appSession.getGenreID()!=""){
                    ivapplyfilter.setVisibility(View.VISIBLE);
                    tvcomedy.setVisibility(View.VISIBLE);
                    tvcomedy.setText(appSession.getGenreID());

                 }
             if (appSession.getYearID()!=""){
                 ivapplyfilter.setVisibility(View.VISIBLE);
                 tvyear.setVisibility(View.VISIBLE);
                    tvyear.setText(appSession.getYearID());
                }
           if (appSession.getReviewID()!=""){
               ivapplyfilter.setVisibility(View.VISIBLE);
               tvreview.setVisibility(View.VISIBLE);
                    tvreview.setText(appSession.getReviewID());
                }
             if (appSession.getStudioID()!=""){
                 ivapplyfilter.setVisibility(View.VISIBLE);
                 tvstudio.setVisibility(View.VISIBLE);
                    tvstudio.setText(appSession.getStudioID());
                }
             if (appSession.getFeatureID()!=""){
                 ivapplyfilter.setVisibility(View.VISIBLE);
                 tvfeature.setVisibility(View.VISIBLE);
                    tvfeature.setText(appSession.getFeatureID());
                }
               if (appSession.getRatingID()!=""){
                   ivapplyfilter.setVisibility(View.VISIBLE);
                   tvrating.setVisibility(View.VISIBLE);
                   tvrating.setText(appSession.getRatingID());
                }





//                textviewvisible();
//                tvcomedy.setText(appSession.getGenreID());
//                tvyear.setText(appSession.getYearID());
//                tvreview.setText(appSession.getReviewID());
//                tvstudio.setText(appSession.getStudioID());
//                tvfeature.setText(appSession.getFeatureID());
//                tvrating.setText(appSession.getRatingID());

            }




        }














    public void getValue(){
        if (!utilities.isNetworkAvailable()) {
            tvMessage.setText(  getResources().getString(R.string.network_error));
            showNoInternet();
        }
        else {
            retrofit = RetrofitUtils.getRetrofitWithoutHeader();
            RestCallInterface restInterface = retrofit.create(RestCallInterface.class);
            //Calling method to get whether report
            Call<ArrayList<Category>> call = restInterface.getAllCategories();
            call.enqueue(new Callback<ArrayList<Category>>() {
                @Override
                public void onResponse(Call<ArrayList<Category>> call, Response<ArrayList<Category>> response) {
                    llLoading.setVisibility(GONE);
                    if (response.isSuccessful()) {

                        try {
                            if (response.code() == 200) {
                                llMessageMain.setVisibility(GONE);

                                tabViewPager = (ViewPager) rootView.findViewById(R.id.tab_viewpager);
                                tabLayout = (TabLayout) rootView.findViewById(R.id.tabLayout);

                                if (tabViewPager != null) {
                                   // setupViewPager(tabViewPager);
                                    ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
                                    int count = response.body().size();

                                    for (int i = 0; i < count; i++) {
                                        movieCategory_lists.addAll(response.body());
                                         adapter.addFrag(new FragmentCategorySdaemonApi(response.body().get(i).getCategoryID().toString()), response.body().get(i).getCategoryDescription());

                                    }
                                    tabViewPager.setAdapter(adapter);
                                   // movieCategory_lists.add   (new MovieCategory_list("ALL MOVIES"));
                                }
                                tabLayout.setupWithViewPager(tabViewPager);
                                int limit = response.body().size();
                                tabViewPager.setOffscreenPageLimit(limit);

                                tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                                    @Override
                                    public void onTabSelected(TabLayout.Tab tab) {
                                        int id = movieCategory_lists.get(tab.getPosition()).getCategoryID();
                                        Toast.makeText(getActivity(),""+id,Toast.LENGTH_LONG).show();

                                        if (id == 1) {
                                     FragmentCategorySdaemonApi.newInstance(tab.getPosition(), String.valueOf(movieCategory_lists.get(tab.getPosition()).getCategoryID()));

                                        }


                                    }

                                    @Override
                                    public void onTabUnselected(TabLayout.Tab tab) {

                                    }

                                    @Override
                                    public void onTabReselected(TabLayout.Tab tab) {

                                    }
                                });

                            } else {
                                tvMessage.setText("" + response.message());
                                showMessage();

                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }



                   /* genreList_adapter = new FeaturesList_Adapter(getActivity(), response.body());
                    featuresListView.setAdapter(genreList_adapter);*/


                    }
                }

                @Override
                public void onFailure(Call<ArrayList<Category>> call, Throwable t) {
                    t.printStackTrace();
                    Toast.makeText(mContext, "" + t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();

                }
            });


        }

    }


    public void refreshPatient(Category category) {
        this.category=category;
//        FragmentCategorySdaemonApi(category.getCategoryID(),category.getCategoryDescription()));
    }

/*
    private void setupViewPager(ViewPager tabViewPager) {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getChildFragmentManager());
        int count = movieCategory_lists.size();
        for (int i = 0; i < count; i++) {
            adapter.addFrag(new FragmentCategory(), movieCategory_lists.get(i).categoryName);
        }
        tabViewPager.setAdapter(adapter);
        movieCategory_lists.add(new MovieCategory_list("ALL MOVIES"));
        movieCategory_lists.add(new MovieCategory_list("POPULAR"));
        movieCategory_lists.add(new MovieCategory_list("TRENDING"));
        movieCategory_lists.add(new MovieCategory_list("DRAMA"));
        movieCategory_lists.add(new MovieCategory_list("RECENT"));

    }*/
       public static Fragment newInstance() {

        Fragment f = new Fragment();
        Bundle args = new Bundle();
        f.setArguments(args);
        return f;
    }



    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
     //  return FragmentCategorySdaemonApi.newInstance(position + 1, String.valueOf(movieCategory_lists.get(position).getCategoryID()));
           return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);


        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    private void setViewPager(){

           for (int i=0;i<images.length;i++){
               imagesArray.add(images[i]);
           }
           if (viewPager!=null){
               viewPager.setAdapter(new MyAdapter(getActivity(),imagesArray));
               circleIndicator.setViewPager(viewPager);
           }

           final Handler handler=new Handler();
           final Runnable runnable=new Runnable() {
               @Override
               public void run() {
                   if (currentPage==images.length){
                       currentPage=0;
                   }
                   viewPager.setCurrentItem(currentPage++,true);
               }
           };
        Timer timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        },3000,3000);


        circleIndicator.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {

            }

            @Override
            public void onPageSelected(int i) {
                        currentPage=i;
            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

//           myPager=new MyPager(getActivity());
//            if (viewPager!=null){
//                viewPager.setAdapter(myPager);
//                circleIndicator.setViewPager(viewPager);
//            }


    }



//    private void scrollViewNewImages(){
//
//     for (Integer image:images){
//         if (llscrollImages!=null){
//             llscrollImages.addView(getImageView(image));
//         }
//     }
//    }

//    private View getImageView(Integer image){
//          ivmovie=new ImageView(getActivity());
//           LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
//           ivmovie.setLayoutParams(lp);
//           ivmovie.setImageResource(image);
//           return ivmovie;
//
//    }
    void showProgress() {
        llMessageMain.setVisibility(View.VISIBLE);
        llLoading.setVisibility(View.VISIBLE);
        tvMessage.setVisibility(GONE);
        tvRetry.setVisibility(GONE);
    }
    void showError() {
        llMessageMain.setVisibility(View.VISIBLE);
        llLoading.setVisibility(GONE);
        tvMessage.setVisibility(View.VISIBLE);
        tvRetry.setVisibility(View.VISIBLE);
    }
    void showMessage() {
        llMessageMain.setVisibility(View.VISIBLE);
        llLoading.setVisibility(GONE);
        tvMessage.setVisibility(View.VISIBLE);
        tvRetry.setVisibility(GONE);
    }
    void showNoInternet() {
        llMessageMain.setVisibility(View.VISIBLE);
        tvMessage.setVisibility(View.VISIBLE);
        tvRetry.setVisibility(View.VISIBLE);
        llLoading.setVisibility(View.GONE);
    }

    boolean textviewInvisible(){
        ivapplyfilter.setVisibility(View.GONE);
        tvcomedy.setVisibility(View.GONE);
        tvyear.setVisibility(View.GONE);
        tvreview.setVisibility(View.GONE);
        tvstudio.setVisibility(View.GONE);
        tvfeature.setVisibility(View.GONE);
        tvrating.setVisibility(View.GONE);

        return true;
    }
}