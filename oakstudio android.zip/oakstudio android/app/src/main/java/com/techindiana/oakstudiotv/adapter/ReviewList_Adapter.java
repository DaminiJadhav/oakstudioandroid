package com.techindiana.oakstudiotv.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import com.mikhaellopez.circularimageview.CircularImageView;
import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.model.ReviewList;
import com.techindiana.oakstudiotv.model.ReviewsList;

import java.util.ArrayList;
import java.util.List;

public class ReviewList_Adapter extends BaseAdapter {

    private static LayoutInflater inflater = null;
    Context context;
    Animation animation;
    private List<ReviewsList> reviewsLists;
    private ArrayList<ReviewList> reviewListArrayList;

    public ReviewList_Adapter(Context context, List<ReviewsList> reviewList) {
        // TODO Auto-generated constructor stub
        this.reviewsLists = reviewList;
        this.context = context;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return reviewsLists.size();
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return position;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return position;
    }


    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        // TODO Auto-generated method stub
        Holder holder = new Holder();
        View rowView;
        rowView = inflater.inflate(R.layout.reviews_list_item, null);
        holder.tv_Name = (TextView) rowView.findViewById(R.id.tv_Name);
        holder.tv_year = (TextView) rowView.findViewById(R.id.tv_year);
        holder.tv_review = (TextView) rowView.findViewById(R.id.tv_review);
        holder.iv_picture = (CircularImageView) rowView.findViewById(R.id.iv_picture);
        holder.reviewRatibgbar = (RatingBar) rowView.findViewById(R.id.reviewRatibgbar);


        holder.tv_Name.setText(reviewsLists.get(position).getFirstName());
        holder.tv_year.setText("July 2018");
        holder.tv_review.setText(reviewsLists.get(position).getReview());
        holder.reviewRatibgbar.setRating(reviewsLists.get(position).getStartRating());

//        holder.tv_Name.setText(reviewListArrayList.get(position).getUserName());
//        holder.tv_year.setText(reviewListArrayList.get(position).getYear());
//        holder.tv_review.setText(reviewListArrayList.get(position).getReviewDesc());
//
//        holder.iv_picture.setImageResource(reviewListArrayList.get(position).getUserImage());

        RatingBar ratingBar = (RatingBar)rowView.findViewById(R.id.reviewRatibgbar);
        Drawable drawable = ratingBar.getProgressDrawable();
        drawable.setColorFilter(Color.parseColor("#FEF400"), PorterDuff.Mode.SRC_ATOP);

       /* holder.reviewRatibgbar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                Intent intent=new Intent(context, ReviewRatingActivity.class);
                context.startActivity(intent);

            }
        });*/

        //Glide.with(ReviewList_Adapter.this).load(reviewListArrayList.get(position).getActorPic()).into(holder.iv_picture);

        return rowView;
    }

    public class Holder {
        TextView tv_Name,tv_year,tv_review;
        CircularImageView iv_picture;
        RatingBar reviewRatibgbar;


    }
}
