package com.techindiana.oakstudiotv.viewpageradapter;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.techindiana.oakstudiotv.R;

import java.util.ArrayList;

public class MyAdapter extends PagerAdapter {
 
    private ArrayList<Integer> images;
    private LayoutInflater inflater;
    private Context contxt;
 
    public MyAdapter(Context context, ArrayList<Integer> images) {
        this.contxt = context;
        this.images=images;
        inflater = LayoutInflater.from(context);
    }
 
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
 
    @Override
    public int getCount() {
        return images.size();
    }
 
    @Override
    public Object instantiateItem(ViewGroup view, int position) {
        View myImageLayout = inflater.inflate(R.layout.imageviewlayout, view, false);
        ImageView myImage = myImageLayout.findViewById(R.id.iv_movie);
        myImage.setImageResource(images.get(position));
        view.addView(myImageLayout, 0);
        return myImageLayout;
    }
 
    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view.equals(object);
    }



    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return "Tab" +position;
//        return super.getPageTitle(position);
    }

}