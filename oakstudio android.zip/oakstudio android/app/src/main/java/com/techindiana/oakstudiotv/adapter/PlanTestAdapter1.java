package com.techindiana.oakstudiotv.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.model.Periodlist;
import com.techindiana.oakstudiotv.utils.OnItemClickListner;

import java.util.List;

public class PlanTestAdapter1 extends RecyclerView.Adapter<PlanTestAdapter1.ViewHolder>{
    private List<Periodlist> list;
    private Context context;
    private OnItemClickListner.OnClickCallback onClickCallback;


    public PlanTestAdapter1(Context context,List<Periodlist> list,OnItemClickListner.OnClickCallback onClickCallback){
        this.context = context;
        this.list = list;
        this.onClickCallback = onClickCallback;
    }

    @NonNull
    @Override
    public PlanTestAdapter1.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.plan_compare_final_test1, viewGroup, false);
        ViewHolder holder = new ViewHolder(v);
        v.setTag(holder);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull PlanTestAdapter1.ViewHolder viewHolder, int i) {
      viewHolder.tvamount.setText(list.get(i).getAmount());
        viewHolder.tvplanname.setText(list.get(i).getName());
        viewHolder.llItem.setOnClickListener(new OnItemClickListner(i, onClickCallback, "test"));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    protected class ViewHolder extends RecyclerView.ViewHolder{

        LinearLayout llItem;
        TextView tvamount,tvplanname;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            llItem = itemView.findViewById(R.id.ll_item1);
            tvamount = itemView.findViewById(R.id.tv_amount);
            tvplanname = itemView.findViewById(R.id.tv_planname);
        }


    }



}
