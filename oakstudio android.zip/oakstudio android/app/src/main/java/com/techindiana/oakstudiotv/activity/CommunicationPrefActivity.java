package com.techindiana.oakstudiotv.activity;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.adapter.CommunicationPrefList_Adapter;
import com.techindiana.oakstudiotv.model.CommunicatonPref_list;

import java.util.ArrayList;

public class CommunicationPrefActivity extends AppCompatActivity {
    private ListView simpleList;
    private ArrayList<CommunicatonPref_list> communicatonPref_lists=new ArrayList<>();
    private CommunicationPrefList_Adapter communicationPrefList_adapter;
    private ImageView iv_tabback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_communication_pref);

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);

        iv_tabback = (ImageView) findViewById(R.id.iv_tabback);
        iv_tabback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        simpleList = (ListView)findViewById(R.id.simpleListView);



        communicatonPref_lists.add(new CommunicatonPref_list("Get notification when your wishlist item is on scale"));
        communicatonPref_lists.add(new CommunicatonPref_list("Update on new release,new features and more"));
        communicatonPref_lists.add(new CommunicatonPref_list("Give your feedback,make OakStudio better"));
        communicatonPref_lists.add(new CommunicatonPref_list("Share my information with oakstudio partners so that they can tell me about new products and special offers"));



        communicationPrefList_adapter = new CommunicationPrefList_Adapter(CommunicationPrefActivity.this, communicatonPref_lists);
        simpleList.setAdapter(communicationPrefList_adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        invalidateOptionsMenu();
        menu.findItem(R.id.action_done).setVisible(true);
        menu.findItem(R.id.action_person).setVisible(false);
        menu.findItem(R.id.action_tuneUp).setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            case R.id.action_done:

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
