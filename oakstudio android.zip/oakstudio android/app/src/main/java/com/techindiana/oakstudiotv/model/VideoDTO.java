package com.techindiana.oakstudiotv.model;

public class VideoDTO {


        String videoUrl = "",date ="";
        Long date_time;
        public VideoDTO(){
        }
        public   VideoDTO(String videoUrl){
            this.videoUrl = videoUrl;
        }
        public   VideoDTO(String videoUrl,String date,Long date_time){
            this.date_time=date_time;
            this.videoUrl = videoUrl;
            this.date = date;
        }
        public Long getDate_time() {
            return date_time;
        }
        public void setDate_time(Long date_time) {
            this.date_time = date_time;
        }
        public String getVideoUrl() {
            return videoUrl;
        }
        public void setVideoUrl(String videoUrl) {
            this.videoUrl = videoUrl;
        }
        public String getDate() {
            return date;
        }
        public void setDate(String date) {
            this.date = date;
        }
    }
