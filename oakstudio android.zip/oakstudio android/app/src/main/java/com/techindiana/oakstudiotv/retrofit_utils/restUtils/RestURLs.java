package com.techindiana.oakstudiotv.retrofit_utils.restUtils;

/**
 * Created by Rahul Patil on 14-02-2018.
 */
public class RestURLs {
    public static final int REQUEST_TIMEOUT = 30000;

    //************** BASE URL *************************
  // public static final String BASE_URL = "http://oakapi.sdaemon.co.in/";
    public static final String BASE_URL = "http://192.168.1.12/OakStudio_Services/";
    public static final String API_KEY = "9kr83fj14fzw02ofi";
    private static final String API_PATH = "api/";
    public static final String COMMON_API_URL = BASE_URL + API_PATH;


}
