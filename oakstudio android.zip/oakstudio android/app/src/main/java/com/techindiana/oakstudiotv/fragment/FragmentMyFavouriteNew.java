package com.techindiana.oakstudiotv.fragment;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.techindiana.oakstudiotv.R;

import android.support.v4.app.FragmentManager;

import com.techindiana.oakstudiotv.utils.Utilities;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentMyFavouriteNew extends Fragment {
    private View rootView;
    private Context context;
    Utilities utilities;
    TabLayout tabLayout;
    ViewPager viewPager;
    public FragmentMyFavouriteNew() {
        // Required empty public constructor

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_fragment_my_favourite, container, false);
        return rootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        context = getActivity();
        utilities = Utilities.getInstance(context);
        initView();

    }

    private void initView() {
        tabLayout = (TabLayout) rootView.findViewById(R.id.myFavouritetabLayout);
        viewPager = (ViewPager) rootView.findViewById(R.id.tab_Favouriteviewpager);
        tabLayout.addTab(tabLayout.newTab().setText("MY MOVIE"));
        tabLayout.addTab(tabLayout.newTab().setText("MY TV SHOWS"));
        tabLayout.addTab(tabLayout.newTab().setText("MY WISHLIST"));
        tabLayout.addTab(tabLayout.newTab().setText("DOWNLOADED"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        //   MyAdapter adapter = new MyAdapter(context, getActivity().getSupportFragmentManager(), tabLayout.getTabCount());
        MyAdapter adapter = new MyAdapter(context, getChildFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        if (!utilities.isNetworkAvailable()) {
            viewPager.setCurrentItem(3);

        }

    }

    public class MyAdapter extends FragmentPagerAdapter {
        private Context myContext;
        int totalTabs;

        public MyAdapter(Context context, FragmentManager fm, int totalTabs) {
            super(fm);
            myContext = context;
            this.totalTabs = totalTabs;
        }

        // this is for fragment tabs
        @Override
        public Fragment getItem(int position) {

            switch (position) {
                case 0:
                    FragmentMyFavouriteMovies fragmentMyFavouriteMovies = new FragmentMyFavouriteMovies();
                    return fragmentMyFavouriteMovies;
                case 1:
                    FragmentMyFavouriteMovies fragmentMyFavouriteMovies1 = new FragmentMyFavouriteMovies();
                    return fragmentMyFavouriteMovies1;

                case 2:
                    FragmentMyFavouriteMovies fragmentMyFavouriteMovies2 = new FragmentMyFavouriteMovies();
                    return fragmentMyFavouriteMovies2;

                case 3:
                    FragmentOffLineDownload fragmentOffLineDownload = new FragmentOffLineDownload();
                    return fragmentOffLineDownload;


                default:
                    return null;
            }
        }// this counts total number of tabs

        @Override
        public int getCount() {
            return totalTabs;
        }
    }


}
