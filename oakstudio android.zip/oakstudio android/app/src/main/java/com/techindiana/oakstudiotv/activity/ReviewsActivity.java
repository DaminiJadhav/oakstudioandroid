package com.techindiana.oakstudiotv.activity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.BoringLayout;
import android.text.GetChars;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.adapter.GenreList_Adapter;
import com.techindiana.oakstudiotv.adapter.ReviewsList_Adapter;
import com.techindiana.oakstudiotv.model.GetFeaturesResp;
import com.techindiana.oakstudiotv.model.GetGenreResp;
import com.techindiana.oakstudiotv.model.GetReviewResp;
import com.techindiana.oakstudiotv.retrofit_utils.RetrofitUtils;
import com.techindiana.oakstudiotv.retrofit_utils.restUtils.RestCallInterface;
import com.techindiana.oakstudiotv.utils.AppSession;
import com.techindiana.oakstudiotv.utils.DialogUtils;
import com.techindiana.oakstudiotv.utils.OnItemClickListner;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class ReviewsActivity extends AppCompatActivity {
    private ListView ReviewsListView;
    private ReviewsList_Adapter genreList_adapter;
    private ImageView iv_tabback;
    private Retrofit retrofit;
    private Context context;
    private ProgressDialog progressDialog;
    AppSession appSession;
    Boolean review=false;
    public static int review_position;
    public static  String review_Name;
    private ArrayList<GetReviewResp> getreview = new ArrayList<>();
    private String reviewName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);
        Bundle bundle=getIntent().getExtras();
        if(bundle!=null) {
            if (bundle.containsKey("KEY_REVIEW"))
                reviewName = bundle.getString("KEY_REVIEW");

        }
        context = this;
        appSession = AppSession.getInstance(context);
        initialize();
        getGenre_Webservice();
    }

    private void initialize() {

        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);

        context = ReviewsActivity.this;
        retrofit = RetrofitUtils.getRetrofitWithoutHeader();
        ReviewsListView = (ListView) findViewById(R.id.ReviewsListView);
        iv_tabback = (ImageView) findViewById(R.id.iv_tabback);

        iv_tabback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }

    private void getGenre_Webservice() {

        showProgress();
        //Creating Rest Services
        RestCallInterface restInterface = retrofit.create(RestCallInterface.class);
        //Calling method to get whether report
        Call<ArrayList<GetReviewResp>> call = restInterface.GetReviewsList();
        call.enqueue(new Callback<ArrayList<GetReviewResp>>() {
            @Override
            public void onResponse(Call<ArrayList<GetReviewResp>> call, Response<ArrayList<GetReviewResp>> response) {
                hideProgress();
                if (response.isSuccessful()) {

                    genreList_adapter = new ReviewsList_Adapter(ReviewsActivity.this, response.body(),onClickCallback,reviewName);
                    getreview.addAll(response.body());
                   ReviewsListView.setAdapter(genreList_adapter);

                }
            }

            @Override
            public void onFailure(Call<ArrayList<GetReviewResp>> call, Throwable t) {
                hideProgress();
                t.printStackTrace();
                Toast.makeText(context, "" + t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if(review==false)
        {
            appSession.setReviewID("");
            appSession.setReviewIDposition(0);
        }
        super.onBackPressed();
        finish();
    }

    @Override
    protected void onPause() {
//        if(review==false)
//        {
//            appSession.setReviewID("");
//            appSession.setReviewIDposition(0);
//        }
        super.onPause();
    }

    @Override
    protected void onStop() {
//        if(review==false)
//        {
//            appSession.setReviewID("");
//            appSession.setReviewIDposition(0);
//        }

        super.onStop();
    }

    @Override
    protected void onDestroy() {
//        if(review==false)
//        {
//            appSession.setReviewID("");
//            appSession.setReviewIDposition(0);
//        }
        super.onDestroy();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        invalidateOptionsMenu();
        menu.findItem(R.id.action_done).setVisible(true);
        menu.findItem(R.id.action_tuneUp).setVisible(false);
        menu.findItem(R.id.action_person).setVisible(false);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onBackPressed();
                return true;

            case R.id.action_done:
                Intent intent = new Intent();
                intent.putExtra("KEY_REVIEW", reviewName);
                setResult(RESULT_OK, intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void hideProgress() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
    }

    public void showProgress() {
        if (progressDialog == null)
            progressDialog = DialogUtils.createProgressDialog(context);
        if (!progressDialog.isShowing())
            progressDialog.show();
    }
    OnItemClickListner.OnClickCallback onClickCallback = new OnItemClickListner.OnClickCallback() {
        @Override
        public void onClicked(View view, int position, String type) {
            if (type.equalsIgnoreCase("")) {
                Toast.makeText(context, "" + getreview.get(position).getDescription().toString(), Toast.LENGTH_LONG).show();
                reviewName=getreview.get(position).getDescription();
                appSession.setReviewID(getreview.get(position).getDescription().toString());
                appSession.setReviewIDposition(getreview.get(position).getID());
                review_position=getreview.get(0).getID();
                review_Name=getreview.get(0).getDescription().toString();
                genreList_adapter.clickreviewposition(position);
                genreList_adapter.notifyDataSetChanged();
            } else {
//                Toast.makeText(context, ""+type.length(), Toast.LENGTH_SHORT).show();
            }
        }
//     appSession.setYearID(getYear.get(position).getDescription());
////                appSession.setYearIDposition(getYear.get(position).getID());
    };




}
