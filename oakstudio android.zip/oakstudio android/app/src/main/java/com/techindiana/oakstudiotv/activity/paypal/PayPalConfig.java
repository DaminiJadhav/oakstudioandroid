package com.techindiana.oakstudiotv.activity.paypal;
public class PayPalConfig {

    public static final String PAYPAL_CLIENT_ID = "ATzQtPxn0NQtNUJg0o2KOJi56bCivbKJnJaE6Yz8crhbi-ljxHOaLkqJ4ioVRofzYheGqVQuhNbIFlRj";

}