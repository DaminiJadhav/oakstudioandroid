package com.techindiana.oakstudiotv.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.dao.RetroClient;
import com.techindiana.oakstudiotv.dto.UsersDTO;
import com.techindiana.oakstudiotv.fragment.FragmentHelpandInfo;
import com.techindiana.oakstudiotv.model.AboutUsResponse;
import com.techindiana.oakstudiotv.utils.AppSession;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class AboutUsActivity extends AppCompatActivity {
    private static final String TAG_FRAGMENT = "fragment";
    TextView tvaboutus;
    AppSession appSession;
    Context context;
    ImageView iv_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        tvaboutus = (TextView) findViewById(R.id.tv_about_us);
        context = this;
        initialize();
        tvaboutus.setMovementMethod(new ScrollingMovementMethod());

//        initialize();

        try {
            appSession = AppSession.getInstance(context);
            if (appSession != null) {
                String content = appSession.getAbout().get(0).getFull();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    tvaboutus.setText(Html.fromHtml(content, Html.FROM_HTML_MODE_LEGACY));

                } else
                    tvaboutus.setText(Html.fromHtml(content));
            }
        }catch (Exception e){
//            Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
        }
    }


    private void initialize(){
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);
        iv_back=(ImageView) findViewById(R.id.iv_tabback);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                getSupportFragmentManager().beginTransaction()
//                        .add(android.R.id.content, new FragmentHelpandInfo()).commit();
//                finish();
            onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        final FragmentHelpandInfo fragment = (FragmentHelpandInfo) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT);
//        FragmentManager fm=getSupportFragmentManager();
//        fm.addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
//            @Override
//            public void onBackStackChanged() {
//                if(getSupportFragmentManager().getBackStackEntryCount() == 0) finish();
//            }
//        });
        super.onBackPressed();
        fragment.onBackPressed();


//        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
//            getSupportFragmentManager().popBackStack();
//        } else {
//            super.onBackPressed();
//        }
    }
}

