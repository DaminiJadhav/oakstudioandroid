package com.techindiana.oakstudiotv.activity;

import android.content.Context;
import android.os.Build;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.fragment.FragmentHelpandInfo;
import com.techindiana.oakstudiotv.utils.AppSession;

public class CookiePolicyActivity extends AppCompatActivity {
    private static final String TAG_FRAGMENT = "fragment";
    TextView tvcookie;
    AppSession appSession;
    Context context;
    ImageView iv_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cookie_policy);

        initialize();

        tvcookie = (TextView) findViewById(R.id.tv_cookiepolicy);
        context = this;
        try {
            appSession = AppSession.getInstance(context);
            String content = appSession.getAbout().get(0).getCookiePolicy();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                tvcookie.setText(Html.fromHtml(content, Html.FROM_HTML_MODE_LEGACY));

            } else
                tvcookie.setText(Html.fromHtml(content));
        }catch (Exception e){

        }
    }
    private void initialize(){
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);
        iv_back=(ImageView) findViewById(R.id.iv_tabback);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                FragmentHelpandInfo fragmentHelpandInfo=new FragmentHelpandInfo();
//                fragmentHelpandInfo.getActivity();
//                getSupportFragmentManager().beginTransaction()
//                        .add(android.R.id.content, new FragmentHelpandInfo()).commit();
             //   finish();
                onBackPressed();
            }
        });
    }

    @Override
    public void onBackPressed() {
        final FragmentHelpandInfo fragment = (FragmentHelpandInfo) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT);
        super.onBackPressed();
        fragment.onBackPressed();
    }
}
