package com.techindiana.oakstudiotv.fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.activity.SelectMovieDetailsActivity;
import com.techindiana.oakstudiotv.dto.ContentDTO;
import com.techindiana.oakstudiotv.model.ContentInfo;
import com.techindiana.oakstudiotv.utils.AppSession;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentMovieDetails_Info extends Fragment {
private View rootView;
ImageView ivmovie;
TextView season,moviefields,rating,minute,cc,showlikes,moviedes;
public List<ContentInfo> list=new ArrayList<>();
private Button btnWatchNow;
Context context;
AppSession appSession;


    public FragmentMovieDetails_Info() {
        // Required empty public constructor
    }

 @SuppressLint("ValidFragment")
 public FragmentMovieDetails_Info(List<ContentInfo>list) {
       this.list=list;
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView= inflater.inflate(R.layout.fragment_fragment_movie_details__info, container, false);
        season=rootView.findViewById(R.id.tv_season);
        moviefields=rootView.findViewById(R.id.tv_moviefield);
        rating=rootView.findViewById(R.id.tv_rating);
        minute= rootView.findViewById(R.id.tv_min);
        cc=rootView.findViewById(R.id.tv_cc);
        showlikes=rootView.findViewById(R.id.tv_showlike);
        moviedes= rootView.findViewById(R.id.tv_movieDescription);
        ivmovie=rootView.findViewById(R.id.iv_movieImage);

        context=rootView.getContext();
      appSession=AppSession.getInstance(context);
//      if (appSession!=null){
//          ContentDTO contentDTO=appSession.getMovieDetail();
//      }
            initialize();
//        getFragmentManager().beginTransaction().detach(this).attach(this).commit();
        return rootView;
    }

    private void initialize() {

        for (int i=0;i<list.size();i++){
            moviefields.setText(list.get(i).getContentTitle());
            rating.setText(list.get(i).getRatingDescription());
            moviedes.setText(list.get(i).getContentDescription());
//            ivmovie.set;
        }

        // ContentDTO contentDTO =appSession.getMovieDetail();
        //   Toast.makeText(context, ""+contentDTO.getContentDetail().getTable().get(0).getContentTitle(), Toast.LENGTH_SHORT).show();
        btnWatchNow=(Button)rootView.findViewById(R.id.btnWatchNow);

        btnWatchNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getActivity(), SelectMovieDetailsActivity.class);
                startActivity(intent);
            }
        });
    }



}
