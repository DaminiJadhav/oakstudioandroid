package com.techindiana.oakstudiotv.activity;

import android.content.Context;
import android.os.Build;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.fragment.FragmentHelpandInfo;
import com.techindiana.oakstudiotv.utils.AppSession;

public class TermsOfUseActivity extends AppCompatActivity {
    private static final String TAG_FRAGMENT = "fragment";
    TextView tvterms;
    AppSession appSession;
    Context context;
    ImageView iv_back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_of_use);
        tvterms=findViewById(R.id.tv_termsofuse);
        context = this;
        initialize();

        try {
            appSession = AppSession.getInstance(context);
            String content = appSession.getAbout().get(0).getTermsOfUse();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                tvterms.setText(Html.fromHtml(content, Html.FROM_HTML_MODE_LEGACY));

            } else
                tvterms.setText(Html.fromHtml(content));
        }catch (Exception e){

        }

    }
    private void initialize(){
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.abs_layout_with_back);
        iv_back=(ImageView) findViewById(R.id.iv_tabback);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                getSupportFragmentManager().beginTransaction()
//                        .replace(android.R.id.content, new FragmentHelpandInfo()).commit();
//                fragmentTransaction.addToBackStack("your_tag");
//                finish();
                onBackPressed();
            }
        });
    }
//
    @Override
    public void onBackPressed() {
        final FragmentHelpandInfo fragment = (FragmentHelpandInfo) getSupportFragmentManager().findFragmentByTag(TAG_FRAGMENT);
        super.onBackPressed();
        fragment.onBackPressed();
    }
}
