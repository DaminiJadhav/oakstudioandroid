package com.techindiana.oakstudiotv.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.adapter.RecentlyViewed_list_Adapter;
import com.techindiana.oakstudiotv.model.Recetly_ViewedDetails;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentRecentlyViewed extends Fragment {
    private View rootView;
    private RecentlyViewed_list_Adapter recentlyViewed_list_adapter;
    private LinearLayoutManager linearLayoutManager;
    StaggeredGridLayoutManager mLayoutManager;
    private RecyclerView rv;
    private ArrayList<Recetly_ViewedDetails> recetly_viewedDetails = new ArrayList<>();

    public FragmentRecentlyViewed() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_fragment_recently_viewed, container, false);
        setData();
        return rootView;
    }

    private void setData() {

        rv = (RecyclerView) rootView.findViewById(R.id.recycler_recentlyViewed);

//        linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
//        rv.setLayoutManager(linearLayoutManager);

        mLayoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        mLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(mLayoutManager);
        rv.setItemAnimator(new DefaultItemAnimator());



        recetly_viewedDetails.add(new Recetly_ViewedDetails(R.drawable.view,"EXPANDABLES 2","(2016)",3,123));
        recetly_viewedDetails.add(new Recetly_ViewedDetails(R.drawable.view4,"MISSION IMPOSSIBLE","(2016)",4,1021));
        recetly_viewedDetails.add(new Recetly_ViewedDetails(R.drawable.view3,"BLACK PANTHER","(2016)",5,500));
        recetly_viewedDetails.add(new Recetly_ViewedDetails(R.drawable.view2,"JUSTICE LEAGUE","(2016)",3,123));
        recetly_viewedDetails.add(new Recetly_ViewedDetails(R.drawable.view1,"ANT-MAN","(2016)",5,854));
        recentlyViewed_list_adapter = new RecentlyViewed_list_Adapter(getActivity(),recetly_viewedDetails);
        rv.setAdapter(recentlyViewed_list_adapter);
    }

}
