package com.techindiana.oakstudiotv.fragment;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.activity.ButtonActivity;
import com.techindiana.oakstudiotv.activity.GenreActivity;
import com.techindiana.oakstudiotv.activity.MovieDetailsActivity;
import com.techindiana.oakstudiotv.adapter.MovieAdapterSdaemon;
import com.techindiana.oakstudiotv.dao.RetroClient;
import com.techindiana.oakstudiotv.dto.CategoryDTO;
import com.techindiana.oakstudiotv.dto.JobDTO;
import com.techindiana.oakstudiotv.dto.ResponseDTO;
import com.techindiana.oakstudiotv.dto.ResultDTO;
import com.techindiana.oakstudiotv.model.Category;
import com.techindiana.oakstudiotv.model.RetroPhoto;

import com.techindiana.oakstudiotv.utils.AppConstants;
import com.techindiana.oakstudiotv.utils.AppSession;
import com.techindiana.oakstudiotv.utils.OnItemClickListner;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentCategorySdaemonApi extends Fragment implements AppConstants {

    StaggeredGridLayoutManager mLayoutManager;
    public View rootView;
    public MovieAdapterSdaemon categoryAdapter;
 //   private MovieAdapter categoryAdapter;
 public Retrofit retrofit;
    public Context context;
    int position;
    String Cat="0";
    String GenresID="0",  YearID="0",  ReviewsID="0",  StudiosID="0", FeaturesID="0",  MPaRatindID="0", ContentTypeID="0",  CategoryID;
    public ProgressDialog progressDialog;
    public  RecyclerView rv;
    public ArrayList<RetroPhoto> trailersByCategory = new ArrayList<>();
    public List<Object> mRecyclerViewItems = new ArrayList<>();
    private static final String ARG_SECTION_NUMBER = "section_number";
    private int sectionNumber;
    AppSession appSession;
    public ResponseDTO responseDTO;

    public FragmentCategorySdaemonApi() {
        // Required empty public constructor
    }
    @SuppressLint("ValidFragment")
    public FragmentCategorySdaemonApi(String CategoryID)
    {

       this.CategoryID=CategoryID;
    }

       public static FragmentCategorySdaemonApi newInstance(int sectionNumber,String CategoryID) {
        FragmentCategorySdaemonApi fragment = new FragmentCategorySdaemonApi();
        Bundle args = new Bundle();
          String Cat=CategoryID;
          args.putString("v",Cat);
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);

        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_fragment_category, container, false);
        if (getArguments()!=null){
            sectionNumber = getArguments().getInt(ARG_SECTION_NUMBER);
            CategoryID=getArguments().getString("v");
        }

        Intent intent=getActivity().getIntent();
        appSession = AppSession.getInstance(context);
        setData();
        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        context = getActivity();
    }

    @Override
    public void onResume() {
        super.onResume();

        //Toast.makeText(getActivity(), "resume", Toast.LENGTH_SHORT).show();
    }

    public void setData() {

        rv = (RecyclerView) rootView.findViewById(R.id.recycler_categoryTrailers);
        mLayoutManager = new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL);
        mLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(mLayoutManager);
        rv.setItemAnimator(new DefaultItemAnimator());

/*
        trailersByCategory.add(new MovieDetails(R.drawable.view, "EXPANDABLE 2", "(2016)", 3, 123));
        trailersByCategory.add(new MovieDetails(R.drawable.view1, "ANT-MAN", "(2016)", 4, 1021));
        trailersByCategory.add(new MovieDetails(R.drawable.view2, "JUSTICE LEAGUE", "(2016)", 5, 500));
        trailersByCategory.add(new MovieDetails(R.drawable.view3, "BLACK PANTHER", "(2016)", 3, 123));
        trailersByCategory.add(new MovieDetails(R.drawable.view4, "MISSION IMPOSSIBLE", "(2016)", 5, 854));*/

      // getCategory("0","0","0","0","0","0","0","0");
      // GenresID= String.valueOf(GenreActivity.gentre_position);
        GenresID=String.valueOf(appSession.getGenreIDposition());
        Log.i("=========G",GenresID );
        YearID=String.valueOf(appSession.getYearIDposition());
        Log.i("=========Y",YearID);
        ReviewsID=String.valueOf(appSession.getReviewIDposition());
        StudiosID=String.valueOf(appSession.getStudioIDposition());
        FeaturesID=String.valueOf(appSession.getFeatureIDposition());
        MPaRatindID=String.valueOf(appSession.getRatingIDposition());
        ContentTypeID= String.valueOf(0);
           getCategory(GenresID,YearID,ReviewsID,StudiosID,FeaturesID,MPaRatindID,ContentTypeID,CategoryID);
    }

    OnItemClickListner.OnClickCallback onClickCallback = new OnItemClickListner.OnClickCallback() {
        @Override
        public void onClicked(View view, int position, String type) {
            if(type.equalsIgnoreCase("image")){
               //Toast.makeText(context,"Image Click",Toast.LENGTH_LONG).show();
                /*if (getArguments() != null) {
                    String mParam1 = getArguments().getString("params");
                    Toast.makeText(getActivity(),mParam1,Toast.LENGTH_LONG).show();
                }*/
             context.startActivity(new Intent(context, MovieDetailsActivity.class));
            //  context.startActivity(new Intent(context, ButtonActivity.class));

            }
            else {

            }
        }
    };

   // public  void getCategory(String GenresID,String YearID,String ReviewsID,String StudiosID,String FeaturesID,String MPaRatindID,String ContentTypeID,String CategoryID){
    public  void getCategory(String GenresID,String YearID,String ReviewsID,String StudiosID,String FeaturesID,String MPaRatindID,String ContentTypeID,String CategoryID){
  //  private void getCategory() {
        // progressBar.show();
       Call<ArrayList<CategoryDTO>> call =  RetroClient.sdaemonApi().getCategory(GenresID,YearID,ReviewsID,StudiosID,FeaturesID,MPaRatindID,ContentTypeID,CategoryID);
      // Call<ArrayList<CategoryDTO>> call =  RetroClient.sdaemonApi().getCategory();

        Log.e(getClass().getName(), "===" + call.request().url());
        call.enqueue(new Callback<ArrayList<CategoryDTO>>() {
            @Override
            public void onResponse(Call<ArrayList<CategoryDTO>> call, Response<ArrayList<CategoryDTO>> response) {
               // Toast.makeText(context, "login successfully", Toast.LENGTH_SHORT).show();
                if (response.isSuccessful()) {
          //   jobList(response.body().toString());


                    Log.i(getClass().getName(), "=========RESPONSE: " + response.body());
                    ArrayList<CategoryDTO> list = new ArrayList<>();
                    list.addAll(response.body());
                    categoryAdapter =new MovieAdapterSdaemon(getActivity(), list,onClickCallback);

                    rv.setAdapter(categoryAdapter);
               }
                else if (response.code() == 409) {
                    try {
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        Log.i(getClass().getName(),"=========RESPONSE: 409 ");
                        String msg = jObjError.getString("message");
                        showDialoge(context, "", msg);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    try {
                        JSONObject jObjError = new JSONObject(response.errorBody().string());
                        Log.i(getClass().getName(),"=========RESPONSE: else ");
                        String msg = jObjError.getString("message");
                        showDialoge(context, "", msg);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<ArrayList<CategoryDTO>> call, Throwable t) {
                //    progressBar.dismiss();

                Log.i(getClass().getName(),"--------------- onFailure "+ t.getMessage());
                showDialoge(context, "", "" + t.getMessage());
            }
        });
    }

    public void showDialoge(Context context, String title, String msg) {
        try {
            AlertDialog.Builder builder;
            builder = new AlertDialog.Builder(context, R.style.dialoge);
            builder.setTitle(title)
                    .setMessage(msg)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })

                    .show();
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    public ResponseDTO parseList(String response) {
        responseDTO = new ResponseDTO();
        ResultDTO resultDTO = null;
        List<JobDTO> list = null;

        try {
            Object object = new JSONTokener(response).nextValue();
            if (object instanceof JSONObject) {
                JSONObject resultObj = getResultJson(response);
                if (resultObj != null) {
                    resultDTO = new ResultDTO();
                    Gson gson = new Gson();
                    if (resultObj.optJSONArray("result") != null) {
                      //  list = gson.fromJson(resultObj.optJSONArray("result").toString(), new TypeToken<ArrayList<JobDTO>>() {
                        list = gson.fromJson(resultObj.optJSONArray("result").toString(), new TypeToken<ArrayList<CategoryDTO>>() {
                        }.getType());
                    }
                    resultDTO.setList1(list);

                }
                responseDTO.setResultDTO(resultDTO);


            } else {
                responseDTO.setStatusCode(0);
                responseDTO.setMessage(UNEXPECTED_RESPONSE + "\nResponse : "
                        + response);
                return responseDTO;
            }
        } catch (Exception e) {
            e.printStackTrace();
            responseDTO.setStatusCode(0);
            responseDTO.setMessage(PARSING_ERROR + "\n" + e.getMessage()
                    + "\nResponse : " + response);
            return responseDTO;
        }

        return responseDTO;
    }


    private JSONObject getResultJson(String response) {
        try {
            Object object = new JSONTokener(response).nextValue();
            if (object instanceof JSONObject) {
                final JSONObject mJSONObject = new JSONObject(response);
                responseDTO.setMessage(mJSONObject.optString("message"));
                responseDTO.setStatusCode(mJSONObject.optInt("status"));
                responseDTO.setProfileImage(mJSONObject.optString("profile_image"));
                responseDTO.setId(mJSONObject.optInt("id"));
                responseDTO.setTime(mJSONObject.optString("time"));
//                if (!TextUtils.isEmpty("" + mJSONObject.optInt("status")) && (mJSONObject.optInt("status") == 4 || mJSONObject.optInt("status") == 3)) {
//                    checkForStatus(mJSONObject.optString("message"));
//                }

                return mJSONObject;
            } else {
                responseDTO.setStatusCode(0);
                responseDTO.setMessage(UNEXPECTED_RESPONSE + "\nResponse : "
                        + response);
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            responseDTO.setStatusCode(0);
            responseDTO.setMessage(PARSING_ERROR + "\n" + e.getMessage()
                    + "\nResponse : " + response);
            return null;
        }
    }


    public ResponseDTO jobList(String res) {
     String response = "";
        try {
          response = res;

        } catch (Exception e) {
            e.printStackTrace();
            ResponseDTO responseDTO = new ResponseDTO();
            responseDTO.setStatusCode(0);
            responseDTO.setMessage(EXCEPTION + "\n" + e.getMessage());
            return responseDTO;
        }
        if (response == null || response.equals(""))
            return null;
        return parseList(response);
    }


}


