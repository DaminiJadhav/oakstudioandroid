package com.techindiana.oakstudiotv.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;

import com.techindiana.oakstudiotv.R;
import com.techindiana.oakstudiotv.fragment.Splash;
import com.techindiana.oakstudiotv.utils.AppConstants;

public class SplashActivity extends AppCompatActivity implements AppConstants {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_new);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        showFragment(new Splash(),"Splash");

    }
    private void showFragment(Fragment targetFragment, String className) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_main, targetFragment, className);
        ft.commitAllowingStateLoss();
    }


}
